﻿namespace FullsteamPay.PosTrac.Control
{
    using System;
    using System.Net.WebSockets;
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using FullsteamPay.PosTrac.Web.Redis;
    using Microsoft.Extensions.Logging;
    using StackExchange.Redis;

    /// <summary>
    /// Represents a web socket host for handling communication with the Fullsteam Gateway API client in the control service.
    /// </summary>
    public class ControlWebSocketHost : RedisWebSocketHost
    {
        /// <summary>
        /// The gRPC client for interacting with terminal data persistence.
        /// </summary>
        private readonly TerminalData.TerminalDataClient client;

        /// <summary>
        /// The JSON serialization options for this instance.
        /// </summary>
        private readonly JsonSerializerOptions localOptions = new()
        {
            Converters = { new JsonStringEnumConverter() },
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ControlWebSocketHost" /> class.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <param name="client">The gRPC client for interacting with terminal data persistence.</param>
        /// <param name="multiplexer">The connection multiplexer for accessing the redis service.</param>
        /// <param name="logger">The logger for this component.</param>
        public ControlWebSocketHost(
            WebSocket socket,
            string socketClientId,
            TerminalData.TerminalDataClient client,
            IConnectionMultiplexer multiplexer,
            ILogger<ControlWebSocketHost> logger)
            : base(socket, socketClientId, multiplexer, logger)
        {
            this.client = client ?? throw new ArgumentNullException(nameof(client));
        }

        /// <inheritdoc />
        protected override JsonSerializerOptions ClientSerializerOptions => this.localOptions;

        /// <inheritdoc />
        protected override string PublishingChannelNameFormat => Constants.RedisBrokerSubscriberChannelNameFormat;

        /// <inheritdoc />
        protected override string SubscribingChannelNameFormat => Constants.RedisControlSubscriberChannelNameFormat;

        /// <inheritdoc />
        public override async Task ProcessConnectionOpenedAsync()
        {
            var request = new TerminalRequest
            {
                TerminalId = this.SocketClientId
            };

            var reply = await this.client.GetTerminalConnectionAsync(request);

            if (reply.Status == FindStatus.NotFound || !reply.IsConnected)
            {
                _ = this.WriteMessageToSocketAsync(TerminalChannelWarning.CreateDefaultNotConnected(this.SocketClientId ?? string.Empty));
            }
        }

        /// <inheritdoc />
        public override Task ProcessSocketMessageAsync(ReadOnlyMemory<byte> buffer) => this.Subscriber.PublishAsync(this.PublishingChannelName, buffer);

        /// <inheritdoc />
        protected override Task ProcessSubscriberMessageAsync(ChannelMessage message) => this.SocketQueue.Writer.WriteAsync(message.Message).AsTask();
    }
}