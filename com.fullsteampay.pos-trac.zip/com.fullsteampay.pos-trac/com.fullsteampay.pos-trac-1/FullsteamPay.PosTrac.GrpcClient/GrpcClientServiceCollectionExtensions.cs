﻿namespace Microsoft.Extensions.DependencyInjection
{
    using System;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Framework;
    using Grpc.Core;
    using Grpc.Net.Client;
    using Grpc.Net.Client.Configuration;
    using Grpc.Net.ClientFactory;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Extension methods for setting up the gRPC clients in the dependency injection container.
    /// </summary>
    public static class GrpcClientServiceCollectionExtensions
    {
        /// <summary>
        /// Adds a typed gRPC client to the <paramref name="services" /> container.
        /// </summary>
        /// <typeparam name="TClient">The type of the gRPC client.</typeparam>
        /// <param name="services">The current collection of dependency injection services.</param>
        /// <returns>A builder for configuring named HTTP client instances returned by the HTTP client factory.</returns>
        /// <remarks>
        /// This service collection "Add*" method does not follow the normal pattern for such methods because of how the
        /// gRPC client factory in-turn adds itself to the collection. It returns an <see cref="IHttpClientBuilder" />
        /// instead of the <see cref="IServiceCollection" /> as normal. This does, however, allow us to chain additional
        /// configuration onto the client as needed.
        /// </remarks>
        public static IHttpClientBuilder AddPersistenceGrpcClient<TClient>(this IServiceCollection services)
            where TClient : class =>
            services.AddGrpcClient<TClient>(ConfigurePersistenceGrpcClient).ConfigureChannel(ConfigureGrpcChannels);

        /// <summary>
        /// An action delegate that configures a <see cref="GrpcChannelOptions" /> instance when creating gRPC channels
        /// in the client factory.
        /// </summary>
        /// <param name="options">The gRPC channel options to configure.</param>
        private static void ConfigureGrpcChannels(GrpcChannelOptions options) =>
            options.ServiceConfig = new()
            {
                // Channel options can be configured per-method and methods are matched using the Names property. This
                // method is configured with MethodName.Default, so it's applied to all gRPC methods called by this channel.
                MethodConfigs =
                {
                    new()
                    {
                        Names = { MethodName.Default },
                        RetryPolicy = new()
                        {
                            BackoffMultiplier = 1.5,
                            InitialBackoff = TimeSpan.FromSeconds(1),
                            MaxAttempts = 5,
                            MaxBackoff = TimeSpan.FromSeconds(5),
                            RetryableStatusCodes = { StatusCode.Unavailable }
                        }
                    }
                }
            };

        /// <summary>
        /// A factory method delegate for creating the persistence gRPC client.
        /// </summary>
        /// <param name="provider">The dependency injection service provider for resolving any needed configuration.</param>
        /// <param name="options">The options to use when creating the gRPC client.</param>
        private static void ConfigurePersistenceGrpcClient(IServiceProvider provider, GrpcClientFactoryOptions options)
        {
            var configuration = provider.GetService<IOptions<PersistenceGrpcClientOptions>>();

            if (configuration is null)
            {
                throw new InvalidOperationException(Strings.PersistenceGrpcClientConfigurationNotRegistered);
            }

            if (string.IsNullOrWhiteSpace(configuration.Value.ServiceEndpoint))
            {
                throw new InvalidOperationException(Strings.PersistenceGrpcClientServiceEndpointNotConfigured);
            }

            options.Address = new Uri(configuration.Value.ServiceEndpoint);
        }
    }
}