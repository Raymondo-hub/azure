﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    using System;
    using System.Collections.Concurrent;
    using System.Threading;

    // TODO: Consider renaming this abstraction to IWebSocketMiniservice and inheriting IMiniservice. Most of the properties here seem to fit in that abstraction better.

    /// <summary>
    /// Defines the members necessary to represent a connection manifest containing all known connections to a web server.
    /// </summary>
    public interface IConnectionManifest
    {
        /// <summary>
        /// Gets the dictionary of hosts currently connected to the server.
        /// </summary>
        /// <value>The dictionary of hosts currently connected to the server.</value>
        public ConcurrentDictionary<Guid, IWebSocketHost> Hosts { get; }

        /// <summary>
        /// Gets a value indicating whether the server is currently running and accepting new connections.
        /// </summary>
        /// <value><c>true</c> if the server is currently running and accepting new connections; otherwise, <c>false</c>.</value>
        public bool IsServerRunning { get; }

        /// <summary>
        /// Gets the cancellation token source for the overall server.
        /// </summary>
        /// <value>The cancellation token source for the overall server.</value>
        public CancellationTokenSource SocketLoopTokenSource { get; }
    }
}