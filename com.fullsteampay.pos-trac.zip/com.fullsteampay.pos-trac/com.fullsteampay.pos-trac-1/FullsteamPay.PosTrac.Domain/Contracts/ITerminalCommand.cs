﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    using System;

    /// <summary>
    /// Defines the members necessary for a command object when dealing with terminal commands.
    /// </summary>
    public interface ITerminalCommand
    {
        /// <summary>
        /// Gets or sets the conversation identifier that uniquely identifies the command message.
        /// </summary>
        /// <value>The conversation identifier that uniquely identifies the command message.</value>
        public Guid ConversationId { get; set; }
    }
}