﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    using System;

    /// <summary>
    /// Defines the members necessary to represent information about a miniservice instance. This generally indicates a
    /// single running instance of an execution unit within the overall application solution.
    /// </summary>
    public interface IMiniservice
    {
        /// <summary>
        /// Gets the unique identifier of the miniservice instance.
        /// </summary>
        /// <value>The unique identifier of the miniservice instance.</value>
        public Guid Id { get; }
    }
}