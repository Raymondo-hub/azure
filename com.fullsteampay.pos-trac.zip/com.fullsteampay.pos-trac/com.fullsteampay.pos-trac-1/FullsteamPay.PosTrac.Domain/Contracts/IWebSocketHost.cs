﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    using System;
    using System.Net.WebSockets;
    using System.Threading;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the members necessary for a host that communicates over web sockets.
    /// </summary>
    public interface IWebSocketHost
    {
        /// <summary>
        /// Gets or sets a source that can be used to create cancellation tokens and indicate when those tokens should cancel.
        /// </summary>
        /// <value>A source used to create and cancel cancellation tokens.</value>
        CancellationTokenSource BroadcastLoopTokenSource { get; set; }

        /// <summary>
        /// Gets the web socket this host is handling.
        /// </summary>
        /// <value>The web socket this host is handling.</value>
        WebSocket Socket { get; }

        /// <summary>
        /// Gets the identifier of the client with which the socket is communicating, if one is available.
        /// </summary>
        /// <value>The identifier of the client with which the socket is communicating.</value>
        string? SocketClientId { get; }

        /// <summary>
        /// Gets the identifier of this web socket host.
        /// </summary>
        /// <value>The identifier of this web socket host.</value>
        Guid SocketId { get; }

        /// <summary>
        /// Gets a task completion token that allows the web socket host to indicate when it is completely finished
        /// hosting the socket, allowing the socket to close.
        /// </summary>
        /// <value>A task completion token indicating when the host is finished.</value>
        TaskCompletionSource<object> TaskCompletion { get; }

        /// <summary>
        /// Performs the work of listending for and sending any messages to the web socket client.
        /// </summary>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task BroadcastLoopAsync();

        /// <summary>
        /// Performs any work required once the web socket connection to the client is closed.
        /// </summary>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task ProcessConnectionClosedAsync();

        /// <summary>
        /// Performs any work required once the web socket connection to the client has been successfully established.
        /// </summary>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task ProcessConnectionOpenedAsync();

        /// <summary>
        /// Processes any messages received from the web socket listening to the client.
        /// </summary>
        /// <param name="buffer">The memory buffer containing the message from the socket.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task ProcessSocketMessageAsync(ReadOnlyMemory<byte> buffer);

        /// <summary>
        /// Performs any additional setup the client needs to enable communication between its components.
        /// </summary>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task SetupAsync();

        /// <summary>
        /// Writes a message to the socket.
        /// </summary>
        /// <typeparam name="TMessage">The type of the message.</typeparam>
        /// <param name="message">The message to write to the socket.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        Task WriteMessageToSocketAsync<TMessage>(TMessage message);
    }
}