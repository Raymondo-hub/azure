﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    using System.Net.WebSockets;

    /// <summary>
    /// Defines the members necessary for a factory that builds hosts for communicating over web sockets.
    /// </summary>
    public interface IWebSocketHostFactory
    {
        /// <summary>
        /// Creates an appropriate web socket host.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <returns>A web socket host.</returns>
        IWebSocketHost CreateHost(WebSocket socket, string socketClientId);
    }
}