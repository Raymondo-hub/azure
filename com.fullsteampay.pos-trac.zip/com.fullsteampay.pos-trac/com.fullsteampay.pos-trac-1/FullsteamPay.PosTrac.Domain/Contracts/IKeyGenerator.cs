﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    /// <summary>
    /// Defines the members necessary for a generator that creates random alphanumeric keys.
    /// </summary>
    public interface IKeyGenerator
    {
        /// <summary>
        /// Gets a random key that can be generated from all possible alphanumeric characters.
        /// </summary>
        /// <param name="size">The size of the key to generate.</param>
        /// <returns>A random key that can be constituted from all possible alphanumeric characters.</returns>
        string GetRandomKey(int size);

        /// <summary>
        /// Gets a random key that can be generated from a reduced set of possible alphanumeric characters that
        /// eliminates lowercase and look-alike characters.
        /// </summary>
        /// <param name="size">The size of the key to generate.</param>
        /// <returns>A random key that can be constituted from a reduced set of possible alphanumeric characters.</returns>
        string GetRandomKeyFromReducedCharSet(int size);
    }
}