﻿namespace FullsteamPay.PosTrac.Domain.Contracts
{
    /// <summary>
    /// Defines the members nessary for an entity in the Azure Cosmos DB service.
    /// </summary>
    public interface ICosmosEntity
    {
        /// <summary>
        /// Gets or sets the identifier of the entity.
        /// </summary>
        /// <value>The identifier of the entity.</value>
        public string? Id { get; set; }
    }
}