﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Defines the different workflows that a terminal can perform.
    /// </summary>
    public enum TerminalWorkflow
    {
        /// <summary>
        /// No value was set.
        /// </summary>
        None = 0,

        /// <summary>
        /// The terminal should perform the transaction workflow.
        /// </summary>
        Transaction = 1
    }
}