﻿namespace FullsteamPay.PosTrac.Domain
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Represents configuration options necessary to configure activation code rotation on the broker service.
    /// </summary>
    public sealed class BrokerCodeRotationOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "BrokerCodeRotation";

        /// <summary>
        /// Gets or sets the time span interval that the broker waits to rotate activation codes for a connected host.
        /// </summary>
        /// <value>The time span interval that the broker waits to rotate activation codes for a connected host.</value>
        [Range(typeof(TimeSpan), Constants.BrokerCodeRotationInternvalMinimumTimeSpanFormat, Constants.BrokerCodeRotationInternvalMaximumTimeSpanFormat)]
        public TimeSpan RotationInterval { get; set; } = TimeSpan.FromSeconds(Constants.BrokerCodeRotationIntervalDefaultSeconds); // TODO: Consider moving constants to some kind of shared file scheme to remove dependency on Framework project? *Shrug* It may be appropriate.
    }
}