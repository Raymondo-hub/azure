﻿namespace FullsteamPay.PosTrac.Domain
{
    using System;
    using System.Globalization;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Represents a warning to hosts on the control service that a terminal channel is indicated as experiencing some
    /// sort of trouble.
    /// </summary>
    public sealed class TerminalChannelWarning
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalChannelWarning" /> class.
        /// </summary>
        /// <param name="statusCode">
        /// The enumeration describing the well-known status code that the terminal channel is experiencing.
        /// </param>
        /// <param name="message">The message text of the warning.</param>
        public TerminalChannelWarning(TerminalChannelWarningStatusCode statusCode, string message)
        {
            if (statusCode == TerminalChannelWarningStatusCode.None)
            {
                throw new ArgumentOutOfRangeException(nameof(statusCode));
            }

            this.StatusCode = statusCode;
            this.Message = message;
        }

        /// <summary>
        /// Gets the message text of the warning.
        /// </summary>
        /// <value>The message text of the warning.</value>
        public string Message { get; }

        /// <summary>
        /// Gets the enumeration describing the well-known status code that the terminal channel is experiencing.
        /// </summary>
        /// <value>The enumeration describing the well-known status code that the terminal channel is experiencing.</value>
        public TerminalChannelWarningStatusCode StatusCode { get; }

        /// <summary>
        /// Creates a default "terminal not connected" warning for the indicated terminal.
        /// </summary>
        /// <param name="terminalId">The identifier of the terminal that is not connected.</param>
        /// <returns>A default "terminal not connected" warning.</returns>
        public static TerminalChannelWarning CreateDefaultNotConnected(string terminalId)
            => new(TerminalChannelWarningStatusCode.NotConnected, string.Format(CultureInfo.CurrentCulture, Strings.TerminalChannelNotConnectedFormat, terminalId));
    }
}