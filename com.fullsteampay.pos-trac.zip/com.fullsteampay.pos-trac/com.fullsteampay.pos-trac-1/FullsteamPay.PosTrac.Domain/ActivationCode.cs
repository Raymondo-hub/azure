﻿namespace FullsteamPay.PosTrac.Domain
{
    using System;

    /// <summary>
    /// Represents a generated activation code associated with a terminal.
    /// </summary>
    public sealed class ActivationCode
    {
        /// <summary>
        /// Gets or sets the code generated for this activation entry.
        /// </summary>
        /// <value>The code generated for this activation entry.</value>
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the date this entity was created.
        /// </summary>
        /// <value>The date this entity was created.</value>
        public DateTimeOffset CreatedDate { get; set; }
    }
}