﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Defines the different supported vendors of terminals.
    /// </summary>
    public enum TerminalVendor
    {
        /// <summary>
        /// No value was set.
        /// </summary>
        None = 0,

        /// <summary>
        /// The terminal vendor is Ingenico.
        /// </summary>
        Ingenico = 1
    }
}