﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Defines the different well-known status codes for terminal channel warnings.
    /// </summary>
    public enum TerminalChannelWarningStatusCode
    {
        /// <summary>
        /// No value was set.
        /// </summary>
        None = 0,

        /// <summary>
        /// The terminal is not connect to its channel.
        /// </summary>
        NotConnected = 1
    }
}