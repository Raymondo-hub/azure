﻿namespace FullsteamPay.PosTrac.Domain
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using FullsteamPay.PosTrac.Domain.Contracts;

    /// <summary>
    /// Represents a generic payment terminal in the persisted data store.
    /// </summary>
    public sealed class Terminal : ICosmosEntity
    {
        /// <summary>
        /// Gets or sets the date this terminal was activated, if terminal is activated.
        /// </summary>
        /// <value>The date this terminal was activated or <c>null</c>.</value>
        public DateTimeOffset? ActivatedDate { get; set; }

        /// <summary>
        /// Gets or sets the collection of activation codes associated with this terminal if it is unregistered.
        /// </summary>
        /// <value>The collection of activation codes associated with this terminal.</value>
        [SuppressMessage("Usage", "CA2227:Collection properties should be read only", Justification = "This property is intended to be used with the JSON serializer.")]
        public ICollection<ActivationCode> ActivationCodes { get; set; } = new HashSet<ActivationCode>();

        /// <summary>
        /// Gets or sets the date this terminal connected to a broker service, if terminal is connected.
        /// </summary>
        /// <value>The date this terminal connected to a broker service or <c>null</c>.</value>
        public DateTimeOffset? ConnectedDate { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the broker service to which the terminal is connected, if terminal is connected.
        /// </summary>
        /// <value>The identifier of the broker service to which the terminal is connected or <c>null</c>.</value>
        public Guid? ConnectedToBrokerId { get; set; }

        /// <summary>
        /// Gets or sets the date this entity was created.
        /// </summary>
        /// <value>The date this entity was created.</value>
        public DateTimeOffset CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the date this terminal was deactivated, if terminal has been deactivated.
        /// </summary>
        /// <value>The date this terminal was deactivated or <c>null</c>.</value>
        public DateTimeOffset? DeactivatedDate { get; set; }

        /// <summary>
        /// Gets or sets the date this terminal disconnected from a broker service, if terminal has disconnected.
        /// </summary>
        /// <value>The date this terminal disconnected from a broker service or <c>null</c>.</value>
        public DateTimeOffset? DisconnectedDate { get; set; }

        /// <summary>
        /// Gets or sets the identifier of this entity.
        /// </summary>
        /// <value>The identifier of this entity.</value>
        public string? Id { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the terminal is activated.
        /// </summary>
        /// <value><c>true</c> if the activated is registered; otherwise, <c>false</c>.</value>
        public bool IsActivated { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the terminal is connected to a broker service.
        /// </summary>
        /// <value><c>true</c> if the terminal is connected to a broker service; otherwise, <c>false</c>.</value>
        public bool IsConnected { get; set; }

        /// <summary>
        /// Gets or sets the serial number of the terminal.
        /// </summary>
        /// <value>The serial number of the terminal.</value>
        public string? SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier of this terminal.
        /// </summary>
        /// <value>The unique identifier of this terminal.</value>
        public string? TerminalId { get; set; }

        /// <summary>
        /// Gets or sets the enumeration describing the vendor of this terminal.
        /// </summary>
        /// <value>The enumeration describing the vendor of this terminal.</value>
        public TerminalVendor Vendor { get; set; }
    }
}