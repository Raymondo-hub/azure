﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Represents configuration options necessary to configure a client/connection multiplexer to the redis service.
    /// </summary>
    public sealed class RedisClientOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "RedisClient";

        /// <summary>
        /// Gets or sets the URL of the endpoint to use when connecting to the redis service.
        /// </summary>
        /// <value>The URL of the endpoint to use when connecting to the redis service.</value>
        public string ServiceEndpoint { get; set; } = string.Empty;
    }
}