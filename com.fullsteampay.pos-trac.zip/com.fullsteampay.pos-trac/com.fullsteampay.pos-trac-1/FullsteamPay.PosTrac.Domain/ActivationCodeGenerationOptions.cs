﻿namespace FullsteamPay.PosTrac.Domain
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Represents configuration options necessary to customize how activation codes are generated.
    /// </summary>
    public sealed class ActivationCodeGenerationOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "ActivationCodeGeneration";

        /// <summary>
        /// Gets or sets the length of the automatically generated portion of the activation code, before any prefixes
        /// or suffixes are added.
        /// </summary>
        /// <value>The length of the automatically generated portion of the activation code.</value>
        [Range(5, 10)]
        public int CodeGenerateLength { get; set; } = Constants.ActivationCodeDefaultCodeGenerateLength;

        /// <summary>
        /// Gets or sets the prefix to add to the beginning of any generated activation codes.
        /// </summary>
        /// <value>The prefix to add to the beginning of any generated activation codes.</value>
        public string CodePrefix { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the maximum number of activation codes to retain for each terminal. Any concurrent code can be
        /// used to activate a terminal.
        /// </summary>
        /// <value>The maximum number of activation codes to retain for each terminal.</value>
        [Range(1, 5)]
        public int MaximumConcurrentCodes { get; set; } = Constants.ActivationCodeDefaultMaximumConcurrentCodes;
    }
}