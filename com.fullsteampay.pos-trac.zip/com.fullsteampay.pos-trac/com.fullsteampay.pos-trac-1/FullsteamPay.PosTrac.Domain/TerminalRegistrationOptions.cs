﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Represents the configuration options necessary to configure the Ingenico terminal registration process.
    /// </summary>
    public sealed class TerminalRegistrationOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "TerminalRegistration";

        /// <summary>
        /// Gets or sets the host portion of the endpoint on the broker service to which the terminal should connect.
        /// </summary>
        /// <value>The host portion of the endpoint on the broker service to which the terminal should connect.</value>
        public string BrokerEndpointHost { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the path portion of the endpoint on the broker service to which the terminal should connect.
        /// </summary>
        /// <value>The path portion of the endpoint on the broker service to which the terminal should connect.</value>
        public string BrokerEndpointPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the port of the endpoint on the service service to which the terminal should connect.
        /// </summary>
        /// <value>The port of the endpoint on the service service to which the terminal should connect.</value>
        public int BrokerEndpointPort { get; set; } = 80;

        /// <summary>
        /// Gets or sets a value indicating whether the endpoint on the broker service to which the terminal should
        /// connect uses TLS encryption.
        /// </summary>
        /// <value><c>true</c> if the endpoint on the broker service uses TLS encryption; otherwise, <c>false</c>.</value>
        public bool BrokerEndpointUseTls { get; set; } = true;
    }
}