﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Represents the configuration options necessary to configure the Azure Table Storage dependency.
    /// </summary>
    public sealed class AzureCosmosOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "AzureCosmos";

        /// <summary>
        /// Gets or sets the Azure Access Key used in conjunction with the connection string to authenticate with Azure.
        /// </summary>
        /// <value>The Azure Access Key used in conjunction with the connection string to authenticate with Azure.</value>
        public string AccessKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the URL of the account endpoint used to connect to the Azure Cosmos provider.
        /// </summary>
        /// <value>The URL of the account endpoint used to connect to the Azure Cosmos provider.</value>
        public string AccountEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the name of the database to use when connecting to Azure Cosmos provider.
        /// </summary>
        /// <value>The name of the database to use when connecting to Azure Cosmos provider.</value>
        public string DatabaseName { get; set; } = string.Empty;
    }
}