﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents the formal response object used by the Ingenico terminal as a result of registering with the system.
    /// </summary>
    public class RegistrationResponse
    {
        /// <summary>
        /// Gets or sets the identifier that indicates the "flow" conversation to which this message belongs.
        /// </summary>
        /// <value>The identifier that indicates the "flow" conversation to which this message belongs.</value>
        public string FlowId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resource associated with the message.
        /// </summary>
        /// <value>The resource associated with the message.</value>
        public RegistrationReplyResource Resource { get; set; } = new();
    }
}