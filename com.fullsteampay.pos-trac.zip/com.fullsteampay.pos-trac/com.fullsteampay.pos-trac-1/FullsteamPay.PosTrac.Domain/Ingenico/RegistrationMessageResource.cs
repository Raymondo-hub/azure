﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Text.Json.Serialization;

    /// <summary>
    /// Represents a resource object as part of a request sent from the Ingenico terminal.
    /// </summary>
    public class RegistrationMessageResource
    {
        /// <summary>
        /// Gets or sets the custom data associated with the request.
        /// </summary>
        /// <value>The custom data associated with the request.</value>
        public RegistrationMessageCustomData CustomData { get; set; } = new();

        /// <summary>
        /// Gets or sets the list of endpoints for which the Ingenico terminal wishes to register.
        /// </summary>
        /// <value>The list of endpoints for which the Ingenico terminal wishes to register.</value>
        [SuppressMessage("Usage", "CA2227:Collection properties should be read only", Justification = "This property is intended to be used with the JSON serializer.")]
        public List<string> Endpoints { get; set; } = new();

        /// <summary>
        /// Gets or sets the serial number of the Ingenico terminal that wishes to register.
        /// </summary>
        /// <value>The serial number of the Ingenico terminal that wishes to register.</value>
        [JsonPropertyName("tsn")]
        public string TerminalSerialNumber { get; set; } = string.Empty;
    }
}