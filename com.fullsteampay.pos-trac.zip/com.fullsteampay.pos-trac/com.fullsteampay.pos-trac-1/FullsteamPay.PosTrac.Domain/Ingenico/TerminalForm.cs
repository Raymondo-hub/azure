﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents a form to display on the Ingenico terminal.
    /// </summary>
    public sealed class TerminalForm
    {
        /// <summary>
        /// Gets or sets the identifier of the terminal form.
        /// </summary>
        /// <value>The identifier of the terminal form.</value>
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the label of the terminal form.
        /// </summary>
        /// <value>The label of the terminal form.</value>
        public string Label { get; set; } = string.Empty;
    }
}