﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// Represents a resource object as part of a message used by the broker service to display a form on the Ingenico terminal.
    /// </summary>
    public sealed class FormMessageResource
    {
        /// <summary>
        /// Gets or sets the list of forms to display on the terminal.
        /// </summary>
        /// <value>The list of forms to display on the terminal.</value>
        [SuppressMessage("Usage", "CA2227:Collection properties should be read only", Justification = "This property is intended to be used with the JSON serializer.")]
        public List<TerminalForm> Texts { get; set; } = new();

        /// <summary>
        /// Gets or sets the type of the form action to perform.
        /// </summary>
        /// <value>The type of the form action to perform.</value>
        public string Type { get; set; } = "update";
    }
}