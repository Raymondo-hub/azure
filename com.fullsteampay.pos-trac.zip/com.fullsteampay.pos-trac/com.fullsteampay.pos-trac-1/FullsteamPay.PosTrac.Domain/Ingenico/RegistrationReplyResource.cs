﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// Represents a resource object as part of a reply sent back to the Ingenico terminal.
    /// </summary>
    public class RegistrationReplyResource
    {
        /// <summary>
        /// Gets or sets the URL to which the Ingenico terminal should connect after registering.
        /// </summary>
        /// <value>The URL to which the Ingenico terminal should connect after registering.</value>
        public Uri ConnectionUrl { get; set; } = new("http://localhost");

        /// <summary>
        /// Gets or sets the list of endpoints for which the Ingenico terminal is registered.
        /// </summary>
        /// <value>The list of endpoints for which the Ingenico terminal is registered.</value>
        [SuppressMessage("Usage", "CA2227:Collection properties should be read only", Justification = "This property is intended to be used with the JSON serializer.")]
        public List<string> Endpoints { get; set; } = new();

        /// <summary>
        /// Gets or sets the enumeration describing the status of the requested process.
        /// </summary>
        /// <value>The enumeration describing the status of the requested process.</value>
        public Status Status { get; set; }
    }
}