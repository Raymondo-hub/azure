﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    using System.Text.Json.Serialization;

    /// <summary>
    /// Represents a reply back to the Ingenico terminal to acknowledge an event.
    /// </summary>
    public sealed class EventAcknowledgementReply
    {
        /// <summary>
        /// Gets or sets the formal response object of the reply.
        /// </summary>
        /// <value>The formal response object of the reply.</value>
        [JsonPropertyName("event_ack")]
        public EventAcknowledgementResponse Response { get; set; } = new();

        /// <summary>
        /// Creates a <see cref="EventAcknowledgementReply" /> object representing the standard message to send to the
        /// terminal to acknowledge an event.
        /// </summary>
        /// <param name="endpoint">The endpoint on which the terminal expects an event acknowledgement.</param>
        /// <param name="flowId">The identifier indicating the current "flow context" of the event.</param>
        /// <returns>An <see cref="EventAcknowledgementReply" /> object representing an event acknowledgement.</returns>
        public static EventAcknowledgementReply CreateStandardEventAcknowledgementRepy(string endpoint, string flowId)
            => new()
            {
                Response = new()
                {
                    Endpoint = endpoint,
                    FlowId = flowId,
                    Resource = new()
                    {
                        Status = Status.Ok
                    }
                }
            };
    }
}