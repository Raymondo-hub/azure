﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents a resource object as part of a reply sent back to the Ingenico terminal to acknowledge an event.
    /// </summary>
    public sealed class EventAcknowledgementReplyResource
    {
        /// <summary>
        /// Gets or sets the enumeration describing the status of the requested process.
        /// </summary>
        /// <value>The enumeration describing the status of the requested process.</value>
        public Status Status { get; set; }
    }
}