﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents the formal response object used by the Ingenico terminal to acknowledge an event.
    /// </summary>
    public sealed class EventAcknowledgementResponse
    {
        /// <summary>
        /// Gets or sets the endpoint the terminal is using.
        /// </summary>
        /// <value>The endpoint the terminal is using.</value>
        public string Endpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the identifier that indicates the "flow" conversation to which this response belongs.
        /// </summary>
        /// <value>The identifier that indicates the "flow" conversation to which this response belongs.</value>
        public string FlowId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resource associated with the reply.
        /// </summary>
        /// <value>The resource associated with the reply.</value>
        public EventAcknowledgementReplyResource Resource { get; set; } = new();
    }
}