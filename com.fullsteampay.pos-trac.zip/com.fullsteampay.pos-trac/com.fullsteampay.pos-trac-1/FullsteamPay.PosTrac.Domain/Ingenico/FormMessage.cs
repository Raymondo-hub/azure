﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    using System.Globalization;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Represents a message from the broker service to the Ingenico terminal to display a form.
    /// </summary>
    public sealed class FormMessage
    {
        /// <summary>
        /// Gets or sets the formal request object of the message.
        /// </summary>
        /// <value>The formal request object of the message.</value>
        public FormRequest Request { get; set; } = new();

        /// <summary>
        /// Creates a <see cref="FormMessage" /> object representing the standard message to send to the terminal to
        /// display an activation code.
        /// </summary>
        /// <param name="activationCode">The activation code to display.</param>
        /// <returns>An <see cref="FormMessage" /> object representing a terminal form.</returns>
        public static FormMessage CreateStandardActivationForm(string activationCode)
        {
            var message = new FormMessage();
            var form = new TerminalForm
            {
                Id = "PROMPTLINE1",
                Label = string.Format(CultureInfo.CurrentCulture, Strings.IngenicoActivationFormLabelFormat, activationCode)
            };

            message.Request.Resource.Texts.Add(form);

            return message;
        }

        /// <summary>
        /// Creates a <see cref="FormMessage" /> object representing the standard message to send to the terminal when a
        /// terminal is activated.
        /// </summary>
        /// <returns>An <see cref="FormMessage" /> object representing a terminal form.</returns>
        public static FormMessage CreateStandardTerminalActivatedForm()
        {
            var message = new FormMessage();
            var form = new TerminalForm
            {
                Id = "PROMPTLINE1",
                Label = Strings.IngenicoTerminalActivatedFormLabel
            };

            message.Request.Resource.Texts.Add(form);

            return message;
        }
    }
}