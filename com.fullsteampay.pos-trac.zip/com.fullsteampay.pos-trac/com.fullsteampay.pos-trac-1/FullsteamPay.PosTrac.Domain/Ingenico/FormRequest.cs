﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents the formal request object used by the broker service to display a form on the Ingenico terminal.
    /// </summary>
    public sealed class FormRequest
    {
        /// <summary>
        /// Gets or sets the endpoint the terminal should use.
        /// </summary>
        /// <value>The endpoint the terminal should use.</value>
        public string Endpoint { get; set; } = "/usi/v1/form";

        /// <summary>
        /// Gets or sets the identifier that indicates the "flow" conversation to which this message belongs.
        /// </summary>
        /// <value>The identifier that indicates the "flow" conversation to which this message belongs.</value>
        public string FlowId { get; set; } = "information";

        /// <summary>
        /// Gets or sets the resource associated with the message.
        /// </summary>
        /// <value>The resource associated with the message.</value>
        public FormMessageResource Resource { get; set; } = new();
    }
}