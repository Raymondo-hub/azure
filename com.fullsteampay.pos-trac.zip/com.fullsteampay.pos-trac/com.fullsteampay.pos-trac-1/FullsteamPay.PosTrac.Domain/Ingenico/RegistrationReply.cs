﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents a reply back to the Ingenico terminal.
    /// </summary>
    public class RegistrationReply
    {
        /// <summary>
        /// Gets or sets the formal response object of the reply.
        /// </summary>
        /// <value>The formal response object of the reply.</value>
        public RegistrationResponse Response { get; set; } = new();
    }
}