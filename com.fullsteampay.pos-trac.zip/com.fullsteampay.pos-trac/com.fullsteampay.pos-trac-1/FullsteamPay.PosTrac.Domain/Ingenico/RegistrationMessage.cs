﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents a message from the Ingenico terminal to register with the system.
    /// </summary>
    public sealed class RegistrationMessage
    {
        /// <summary>
        /// Gets or sets the formal request object of the message.
        /// </summary>
        /// <value>The formal request object of the message.</value>
        public RegistrationRequest Request { get; set; } = new();
    }
}