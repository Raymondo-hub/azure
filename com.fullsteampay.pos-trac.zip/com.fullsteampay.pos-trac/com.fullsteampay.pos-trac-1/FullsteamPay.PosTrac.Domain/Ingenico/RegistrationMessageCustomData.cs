﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents the custom data as part of a request sent from the Ingenico terminal.
    /// </summary>
    public class RegistrationMessageCustomData
    {
        /// <summary>
        /// Gets or sets the identifier of the merchant associated with the Ingenico terminal.
        /// </summary>
        /// <value>The identifier of the merchant associated with the Ingenico terminal.</value>
        public string MerchantId { get; set; } = string.Empty;
    }
}