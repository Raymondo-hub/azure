﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Defines the different status values that can be returned to an Ingenico terminal in response to a message.
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// No value was set.
        /// </summary>
        None = 0,

        /// <summary>
        /// The message was handled successfully.
        /// </summary>
        Ok = 1,

        /// <summary>
        /// The message encountered an error.
        /// </summary>
        Error = 2,

        /// <summary>
        /// The transaction flow was successfully started.
        /// </summary>
        Started = 3
    }
}