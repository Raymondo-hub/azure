﻿namespace FullsteamPay.PosTrac.Domain.Ingenico
{
    /// <summary>
    /// Represents the formal request object used by the Ingenico terminal to register with the system.
    /// </summary>
    public class RegistrationRequest
    {
        /// <summary>
        /// Gets or sets the identifier that indicates the "flow" conversation to which this message belongs.
        /// </summary>
        /// <value>The identifier that indicates the "flow" conversation to which this message belongs.</value>
        public string FlowId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resource associated with the message.
        /// </summary>
        /// <value>The resource associated with the message.</value>
        public RegistrationMessageResource Resource { get; set; } = new();
    }
}