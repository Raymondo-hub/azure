﻿namespace FullsteamPay.PosTrac.Domain
{
    /// <summary>
    /// Represents configuration options necessary to configure a gRPC client connecting to the persistence service.
    /// </summary>
    public sealed class PersistenceGrpcClientOptions
    {
        /// <summary>
        /// The name of the configuration section in the provider.
        /// </summary>
        public const string SectionName = "PersistenceGrpcClient";

        /// <summary>
        /// Gets or sets the URL of the endpoint to use when connecting to the persistence service.
        /// </summary>
        /// <value>The URL of the endpoint to use when connecting to the persistence service.</value>
        public string ServiceEndpoint { get; set; } = string.Empty;
    }
}