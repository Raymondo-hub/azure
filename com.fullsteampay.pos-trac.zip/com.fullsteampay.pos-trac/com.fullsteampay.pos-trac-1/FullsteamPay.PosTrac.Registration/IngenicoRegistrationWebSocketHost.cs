﻿namespace FullsteamPay.PosTrac.Registration
{
    using System;
    using System.Net.WebSockets;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Domain.Ingenico;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using FullsteamPay.PosTrac.Web;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Represents a web socket host for handling communication with an Ingenico terminal in the registration service.
    /// </summary>
    public sealed class IngenicoRegistrationWebSocketHost : BaseWebSocketHost
    {
        /// <summary>
        /// The gRPC client for interacting with terminal data persistence.
        /// </summary>
        private readonly TerminalData.TerminalDataClient client;

        /// <summary>
        /// The configuration options for terminal registration.
        /// </summary>
        private readonly TerminalRegistrationOptions options;

        /// <summary>
        /// Initializes a new instance of the <see cref="IngenicoRegistrationWebSocketHost" /> class.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <param name="client">The gRPC client for interacting with terminal data persistence.</param>
        /// <param name="options">The configuration options for terminal registration.</param>
        /// <param name="logger">The logger for this component.</param>
        public IngenicoRegistrationWebSocketHost(
            WebSocket socket,
            string socketClientId,
            TerminalData.TerminalDataClient client,
            IOptions<TerminalRegistrationOptions> options,
            ILogger<IngenicoRegistrationWebSocketHost> logger)
            : base(socket, socketClientId, logger)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            this.client = client ?? throw new ArgumentNullException(nameof(client));
            this.options = options.Value;
        }

        /// <inheritdoc />
        public override async Task ProcessSocketMessageAsync(ReadOnlyMemory<byte> buffer)
        {
            var message = await this.ReceiveClientMessageAsync<RegistrationMessage>(buffer);

            // TODO: Add AutoMapper.
            var request = new RegisterRequest
            {
                TerminalSerialNumber = message.Request.Resource.TerminalSerialNumber,
                TerminalVendor = Persistence.Protos.TerminalVendor.Ingenico
            };

            var reply = await this.client.RegisterAsync(request);

            // This terminal ID should already be normalized as it is coming from persistence.
            this.SocketClientId = reply.TerminalId;

            this.Logger.LogInformation($"Socket {this.SocketId}: Terminal ID is {reply.TerminalId}");

            var result = this.CreateTerminalReply(message, reply);

            // With the v1.19 of the iConnect web socket firmware for Ingenico terminals, returning just the single "/"
            // seems to be the only way to make the terminal behave as it should with regards to the multiconnect issue.
            // Previously, this echoed back the same list as it received in the request but upon receiving the
            // registration reponse the terminal would attempt to connect to each endpoint appended to the connection
            // URL. So if connection URL was "ws://postrac.fullsteam.com/control" and the endpoints mirrored the request
            // (which returns 8 such as "/usi/v1/linedisplay"), the terminal would try to connect to
            // "ws://postrac.fullsteam.com/control/usi/v1/linedisplay" and then all other endpoints. Returning the
            // single "/", it correctly connects to only "ws://postrac.fullsteam.com/control".
            result.Response.Resource.Endpoints.Add("/");

            await this.WriteMessageToSocketAsync(result);
        }

        /// <summary>
        /// Creates a reply to send to the terminal describing the result of the registration process.
        /// </summary>
        /// <param name="terminalMessage">The original request message from the terminal.</param>
        /// <param name="persistenceReply">The reply from the persistence service storing the registration.</param>
        /// <returns>A reply to send to the terminal.</returns>
        private RegistrationReply CreateTerminalReply(RegistrationMessage terminalMessage, RegisterReply? persistenceReply)
        {
            return new RegistrationReply
            {
                Response = new()
                {
                    FlowId = terminalMessage.Request.FlowId,
                    Resource = new()
                    {
                        ConnectionUrl = this.options.ToBrokerEndpointUri(this.SocketClientId),
                        Status = persistenceReply is null ? Status.Error : Status.Ok // TODO: This is not a good way to check this.
                    }
                }
            };
        }
    }
}