﻿namespace FullsteamPay.PosTrac.Registration
{
    using System;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using FullsteamPay.PosTrac.Web;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    /// <summary>
    /// Represents the bootstrapper for initializing configuration and services for the registration service.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Configure the HTTP request pipeline. This method is called by the runtime.
        /// </summary>
        /// <param name="app">Provides the mechanisms to configure the applications request pipeline.</param>
        public void Configure(IApplicationBuilder app)
        {
            app.UseWebSockets(new WebSocketOptions
            {
                // TODO: Revisit this in the future. Fred's jMeter load testing doesn't like the server-side
                // unidirectional heartbeat (which is what this is) so it's disabled for the moment at Fred's behest. I
                // suspect turning it off makes client hard disconnects harder to detect, but we'll see.
                KeepAliveInterval = TimeSpan.Zero
            });

            app.UseMiddleware<WebSocketHostMiddleware>();
        }

        /// <summary>
        /// Configure services in the dependency injection container. This method is called by the runtime.
        /// </summary>
        /// <param name="services">The collection of dependency injection service descriptors for the application.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetry();

            // These options are added to the service collection here instead of in AddPersistenceGrpcClient because
            // that method can be called multiple times, and we do not want to register the options each time we do
            // that. As far as I am aware, there is no TryAddOptions method that would smooth over that particular problem.
            services.AddOptions<PersistenceGrpcClientOptions>().BindConfiguration(PersistenceGrpcClientOptions.SectionName);
            services.AddOptions<TerminalRegistrationOptions>().BindConfiguration(TerminalRegistrationOptions.SectionName);
            services.AddPersistenceGrpcClient<TerminalData.TerminalDataClient>();
            services.AddWebSocketHostMiddleware<IngenicoRegistrationWebSocketHost>();
        }
    }
}