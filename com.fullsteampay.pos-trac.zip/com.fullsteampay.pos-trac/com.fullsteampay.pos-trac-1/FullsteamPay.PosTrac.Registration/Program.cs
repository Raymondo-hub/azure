﻿namespace FullsteamPay.PosTrac.Registration
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Represents the primary execution unit of this application.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Configures the web host for the application.
        /// </summary>
        /// <param name="args">The collection of command line arguments passed into the runtime.</param>
        /// <returns>An abstraction for building the web host.</returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    // The address the host listens on should be set with the ASPNETCORE_URLS environment variable. This
                    // value is set by the "applicationUrl" from the launchSettings.json file per profile.
                    webBuilder.UseStartup<Startup>();

                    // TODO: Switch to actual logging framework and remove references to Microsoft.Extensions.Logging (if necessary).
                    webBuilder.ConfigureLogging(c => c.AddSimpleConsole(o => o.TimestampFormat = "[MM/dd/yyyy HH:mm:ss] "));
                });

        /// <summary>
        /// The main entry point for the application executed by the runtime.
        /// </summary>
        /// <param name="args">The collection of command line arguments passed into the runtime.</param>
        public static void Main(string[] args) => CreateHostBuilder(args).Build().Run();
    }
}