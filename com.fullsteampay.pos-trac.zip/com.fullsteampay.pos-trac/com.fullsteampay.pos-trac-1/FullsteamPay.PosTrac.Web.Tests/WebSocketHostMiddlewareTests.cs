﻿namespace FullsteamPay.PosTrac.Web.Tests
{
    using System;
    using System.Collections.Concurrent;
    using System.Net;
    using System.Net.WebSockets;
    using System.Threading;
    using System.Threading.Tasks;
    using FluentAssertions;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.TestHost;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Moq;
    using Xunit;

    public class WebSocketHostMiddlewareTests
    {
        private readonly Uri webSocketUri = new("ws://www.example.com");

        [Fact]
        public async Task NonWebSocketRequestWithHttpUriShouldIndicateNotFound()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();
            var httpUri = new Uri("http://www.example.com");

            using var host = await StartHost(context);
            var server = host.GetTestServer();

            server.BaseAddress = httpUri;

            var serverReponse = await server.SendAsync(c => c.Request.Method = HttpMethods.Get);

            serverReponse.Response.StatusCode.Should().Be((int)HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task NonWebSocketRequestWithWebSocketUriShouldIndicateNotFound()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();

            using var host = await StartHost(context);
            var server = host.GetTestServer();

            server.BaseAddress = this.webSocketUri;

            var serverReponse = await server.SendAsync(c => c.Request.Method = HttpMethods.Get);

            serverReponse.Response.StatusCode.Should().Be((int)HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task ServerNotRunningShouldIndicateConflict()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();

            context.Manifest.Setup(e => e.IsServerRunning).Returns(false);

            using var host = await StartHost(context);
            var server = host.GetTestServer();

            server.BaseAddress = this.webSocketUri;

            var serverReponse = await server.SendAsync(c => c.Request.Method = HttpMethods.Get);

            serverReponse.Response.StatusCode.Should().Be((int)HttpStatusCode.Conflict);
        }

        [Fact]
        public async Task WebSocketHostShouldInvokeProcessConnectionOpened()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();
            var clientSource = new CancellationTokenSource();

            using var host = await StartHost(context);
            var socket = await SetupWebSocket(host, this.webSocketUri, CancellationToken.None);

            await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, clientSource.Token);

            context.WebSocketHost.Verify(e => e.ProcessConnectionOpenedAsync(), Times.Once);
        }

        [Fact]
        public async Task WebSocketHostShouldInvokeSetup()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();
            var clientSource = new CancellationTokenSource();

            using var host = await StartHost(context);
            var socket = await SetupWebSocket(host, this.webSocketUri, clientSource.Token);

            await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, clientSource.Token);

            context.WebSocketHost.Verify(e => e.SetupAsync(), Times.Once);
        }

        [Fact]
        public async Task WebSocketRequestWithHttpUriShouldOpenSocket()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();
            var httpUri = new Uri("http://www.example.com");
            var clientSource = new CancellationTokenSource();

            using var host = await StartHost(context);
            var server = host.GetTestServer();

            var socket = await SetupWebSocket(host, httpUri, clientSource.Token);

            socket.State.Should().Be(WebSocketState.Open);

            await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, clientSource.Token);
        }

        [Fact]
        public async Task WebSocketRequestWithWebSocketUriShouldOpenSocket()
        {
            var context = WebSocketHostTestContext.SetupBasicContext();
            var clientSource = new CancellationTokenSource();

            using var host = await StartHost(context);
            var socket = await SetupWebSocket(host, this.webSocketUri, clientSource.Token);

            socket.State.Should().Be(WebSocketState.Open);

            await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, clientSource.Token);
        }

        private static Task<WebSocket> SetupWebSocket(IHost host, Uri hostUri, CancellationToken cancellationToken)
        {
            var server = host.GetTestServer();

            server.BaseAddress = hostUri;

            var client = server.CreateWebSocketClient();

            return client.ConnectAsync(hostUri, cancellationToken);
        }

        private static Task<IHost> StartHost(Mock<IConnectionManifest> manifest, Mock<IWebSocketHostFactory> factory)
        {
            return new HostBuilder()
                .ConfigureWebHost(webBuilder =>
                {
                    webBuilder
                        .UseTestServer()
                        .ConfigureServices(services =>
                        {
                            services.AddSingleton(manifest.Object);
                            services.AddSingleton(factory.Object);
                            services.AddScoped<WebSocketHostMiddleware>();
                        })
                        .Configure(app =>
                        {
                            app.UseMiddleware<WebSocketHostMiddleware>();
                        });
                })
                .StartAsync();
        }

        private static Task<IHost> StartHost(WebSocketHostTestContext context) => StartHost(context.Manifest, context.Factory);

        private class WebSocketHostTestContext
        {
            public Mock<IWebSocketHostFactory> Factory { get; set; }

            public TaskCompletionSource<object> HostTaskCompletionSource { get; set; }

            public CancellationTokenSource HostTokenSource { get; set; }

            public Mock<IConnectionManifest> Manifest { get; set; }

            public ConcurrentDictionary<Guid, IWebSocketHost> ManifestHosts { get; set; }

            public CancellationTokenSource ServerTokenSource { get; set; }

            public WebSocket Socket { get; set; }

            public Mock<IWebSocketHost> WebSocketHost { get; set; }

            public static WebSocketHostTestContext SetupBasicContext()
            {
                var manifest = new Mock<IConnectionManifest>();
                var factory = new Mock<IWebSocketHostFactory>();
                var webSocketHost = new Mock<IWebSocketHost>();
                WebSocket serverSocket = null;
                var hostTaskCompletionSource = new TaskCompletionSource<object>();
                var hosts = new ConcurrentDictionary<Guid, IWebSocketHost>();
                var hostTokenSource = new CancellationTokenSource();
                var serverTokenSource = new CancellationTokenSource();

                manifest.Setup(e => e.Hosts).Returns(hosts);
                manifest.Setup(e => e.IsServerRunning).Returns(true);
                manifest.Setup(e => e.SocketLoopTokenSource).Returns(serverTokenSource);
                factory.Setup(e => e.CreateHost(It.IsAny<WebSocket>(), It.IsAny<string>())).Returns(webSocketHost.Object).Callback<WebSocket, string>((w, s) => serverSocket = w);
                webSocketHost.Setup(e => e.BroadcastLoopTokenSource).Returns(hostTokenSource);
                webSocketHost.Setup(e => e.Socket).Returns(() => serverSocket);
                webSocketHost.Setup(e => e.TaskCompletion).Returns(hostTaskCompletionSource);

                return new()
                {
                    Factory = factory,
                    HostTaskCompletionSource = hostTaskCompletionSource,
                    HostTokenSource = hostTokenSource,
                    Manifest = manifest,
                    ManifestHosts = hosts,
                    ServerTokenSource = serverTokenSource,
                    Socket = serverSocket,
                    WebSocketHost = webSocketHost
                };
            }
        }
    }
}