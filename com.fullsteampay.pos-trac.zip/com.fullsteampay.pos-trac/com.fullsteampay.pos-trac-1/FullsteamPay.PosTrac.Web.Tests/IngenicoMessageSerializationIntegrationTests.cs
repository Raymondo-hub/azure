﻿namespace FullsteamPay.PosTrac.Web.Tests
{
    using System;
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using FluentAssertions;
    using FullsteamPay.PosTrac.Domain.Ingenico;
    using FullsteamPay.PosTrac.Framework;
    using Xunit;

    public class IngenicoMessageSerializationIntegrationTests
    {
        private static EventAcknowledgementReply BasicEventAcknowledgementReply
            => new()
            {
                Response = new()
                {
                    Endpoint = "/usi/v1/transaction",
                    FlowId = "12345678",
                    Resource = new()
                    {
                        Status = Status.Ok
                    }
                }
            };

        private static string BasicEventAcknowledgementReplyJson =>
@"{
  ""event_ack"": {
    ""endpoint"": ""/usi/v1/transaction"",
    ""flow_id"": ""12345678"",
    ""resource"": {
      ""status"": ""ok""
    }
  }
}";

        private static FormMessage BasicFormMessage
                            => new()
                            {
                                Request = new()
                                {
                                    FlowId = "confirm",
                                    Endpoint = "/usi/v1/form",
                                    Resource = new()
                                    {
                                        Texts = new()
                                        {
                                            new() { Id = "PROMPTLINE1", Label = "Activation Code abcd1234" }
                                        },
                                        Type = "update"
                                    }
                                }
                            };

        private static string BasicFormMessageJson =>
@"{
  ""request"": {
    ""endpoint"": ""/usi/v1/form"",
    ""flow_id"": ""confirm"",
    ""resource"": {
      ""texts"": [
        {
          ""id"": ""PROMPTLINE1"",
          ""label"": ""Activation Code abcd1234""
        }
      ],
      ""type"": ""update""
    }
  }
}";

        private static RegistrationMessage BasicRegistrationMessage
            => new()
            {
                Request = new()
                {
                    FlowId = "register",
                    Resource = new()
                    {
                        CustomData = new()
                        {
                            MerchantId = "12345"
                        },
                        Endpoints = new()
                        {
                            "/",
                            "/usi/v1/",
                            "/usi/v1/transaction",
                            "/usi/v1/update",
                            "/usi/v1/log",
                            "/usi/v1/device",
                            "/usi/v1/form",
                            "/usi/v1/linedisplay",
                            "/usi/v1/audio"
                        },
                        TerminalSerialNumber = "201167303011023914577853"
                    }
                }
            };

        private static string BasicRegistrationMessageJson =>
        @"
{
    ""request"": {
        ""flow_id"": ""register"",
        ""resource"": {
            ""custom_data"": {
                ""merchant_id"": ""12345""
            },
            ""endpoints"": [
                ""/"",
                ""/usi/v1/"",
                ""/usi/v1/transaction"",
                ""/usi/v1/update"",
                ""/usi/v1/log"",
                ""/usi/v1/device"",
                ""/usi/v1/form"",
                ""/usi/v1/linedisplay"",
                ""/usi/v1/audio""
            ],
            ""tsn"": ""201167303011023914577853""
        }
    }
}
";

        private static RegistrationReply BasicRegistrationReply
            => new()
            {
                Response = new()
                {
                    FlowId = "register",
                    Resource = new()
                    {
                        ConnectionUrl = new Uri("ws://192.168.1.145:50002"),
                        Endpoints = new()
                        {
                            "/",
                            "/usi/v1/",
                            "/usi/v1/transaction",
                            "/usi/v1/update",
                            "/usi/v1/log",
                            "/usi/v1/device",
                            "/usi/v1/form",
                            "/usi/v1/linedisplay",
                            "/usi/v1/audio"
                        },
                        Status = Status.Ok
                    }
                }
            };

        private static string BasicRegistrationReplyJson =>
        @"{
  ""response"": {
    ""flow_id"": ""register"",
    ""resource"": {
      ""connection_url"": ""ws://192.168.1.145:50002"",
      ""endpoints"": [
        ""/"",
        ""/usi/v1/"",
        ""/usi/v1/transaction"",
        ""/usi/v1/update"",
        ""/usi/v1/log"",
        ""/usi/v1/device"",
        ""/usi/v1/form"",
        ""/usi/v1/linedisplay"",
        ""/usi/v1/audio""
      ],
      ""status"": ""ok""
    }
  }
}";

        private static JsonSerializerOptions DefaultOptions
            => new()
            {
                Converters = { new JsonStringEnumConverter(new JsonSnakeCaseNamingPolicy()) },
                PropertyNamingPolicy = new JsonSnakeCaseNamingPolicy(),
                WriteIndented = true
            };

        [Fact]
        public void BasicEventAcknowledgementShouldSerialize()
        {
            var actual = JsonSerializer.Serialize(BasicEventAcknowledgementReply, DefaultOptions);

            actual.Should().Be(BasicEventAcknowledgementReplyJson);
        }

        [Fact]
        public void BasicFormMessageShouldSerialize()
        {
            var actual = JsonSerializer.Serialize(BasicFormMessage, DefaultOptions);

            actual.Should().Be(BasicFormMessageJson);
        }

        [Fact]
        public void BasicRegistrationMessageJsonShouldDeserialize()
        {
            var actual = JsonSerializer.Deserialize<RegistrationMessage>(BasicRegistrationMessageJson, DefaultOptions);

            actual.Should().BeEquivalentTo(BasicRegistrationMessage);
        }

        [Fact]
        public void BasicRegistrationReplyShouldSerialize()
        {
            var actual = JsonSerializer.Serialize(BasicRegistrationReply, DefaultOptions);

            actual.Should().Be(BasicRegistrationReplyJson);
        }
    }
}