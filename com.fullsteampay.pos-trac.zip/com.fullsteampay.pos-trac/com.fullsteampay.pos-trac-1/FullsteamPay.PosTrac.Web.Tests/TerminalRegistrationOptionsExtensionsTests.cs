﻿namespace FullsteamPay.PosTrac.Web.Tests
{
    using System;
    using FluentAssertions;
    using FullsteamPay.PosTrac.Domain;
    using Xunit;

    public class TerminalRegistrationOptionsExtensionsTests
    {
        public static TheoryData<string, string> HandledPathValues
            => new()
            {
                { null, "ws://host/1234" },
                { string.Empty, "ws://host/1234" },
                { "     ", "ws://host/     /1234" },
                { "   path     ", "ws://host/   path     /1234" },
                { "path/", "ws://host/path/1234" },
                { "path", "ws://host/path/1234" }
            };

        public static TheoryData<string, string> HandledTerminalIdValues
            => new()
            {
                { null, "ws://host/path" },
                { string.Empty, "ws://host/path" },
                { "     ", "ws://host/path/     " },
                { "   1234     ", "ws://host/path/   1234     " },
                { "1234", "ws://host/path/1234" }
            };

        [Theory]
        [MemberData(nameof(HandledPathValues))]
        public void ToBrokerEndpointUriShouldHandleSpecificPathValues(string input, string expected)
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = "host",
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            options.BrokerEndpointPath = input;

            var actual = options.ToBrokerEndpointUri("1234");

            actual.ToString().Should().Be(expected);
        }

        [Theory]
        [MemberData(nameof(HandledTerminalIdValues))]
        public void ToBrokerEndpointUriShouldHandleSpecificTerminalIdValues(string input, string expected)
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = "host",
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            var actual = options.ToBrokerEndpointUri(input);

            actual.ToString().Should().Be(expected);
        }

        [Fact]
        public void ToBrokerEndpointUriWithEmptyHostOptionShouldThrow()
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = string.Empty,
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            Action testCode = () => options.ToBrokerEndpointUri("1234");

            testCode.Should().Throw<ArgumentException>();
        }

        [Fact]
        public void ToBrokerEndpointUriWithNullHostOptionShouldThrow()
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = null,
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            Action testCode = () => options.ToBrokerEndpointUri("1234");

            testCode.Should().Throw<ArgumentException>();
        }

        [Fact]
        public void ToBrokerEndpointUriWithTlsDisabledShouldUseWsProtocol()
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = "host",
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            var actual = options.ToBrokerEndpointUri("1234");

            actual.ToString().Should().Be("ws://host/path/1234");
        }

        [Fact]
        public void ToBrokerEndpointUriWithTlsEnabledShouldUseWssProtocol()
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = "host",
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 443,
                BrokerEndpointUseTls = true
            };

            var actual = options.ToBrokerEndpointUri("1234");

            actual.ToString().Should().Be("wss://host/path/1234");
        }

        [Fact]
        public void ToBrokerEndpointUriWithWhiteSpaceHostOptionShouldThrow()
        {
            var options = new TerminalRegistrationOptions
            {
                BrokerEndpointHost = "    ",
                BrokerEndpointPath = "path",
                BrokerEndpointPort = 80,
                BrokerEndpointUseTls = false
            };

            Action testCode = () => options.ToBrokerEndpointUri("1234");

            testCode.Should().Throw<ArgumentException>();
        }
    }
}