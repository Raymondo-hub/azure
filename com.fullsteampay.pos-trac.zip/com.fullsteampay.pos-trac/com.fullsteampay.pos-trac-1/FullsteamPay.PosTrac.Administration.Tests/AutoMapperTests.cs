﻿namespace FullsteamPay.PosTrac.Administration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using FluentAssertions;
    using FullsteamPay.PosTrac.Administration.Protos;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using Xunit;

    public class AutoMapperTests
    {
        private readonly IMapper mapper;

        public AutoMapperTests()
        {
            var config = new MapperConfiguration(c => c.AddMaps(typeof(TerminalAdministrationProfile)));

            this.mapper = config.CreateMapper();
        }

        [Fact]
        public void AdministrationActivateActivationCodeRequestShouldMapToPersistence()
        {
            var source = new PosTracActivateActivationCodeRequest
            {
                ActivationCode = "123"
            };

            var actual = this.mapper.Map<ActivateActivationCodeRequest>(source);

            actual.ActivationCode.Should().Be("123");
        }

        [Fact]
        public void AdministrationActivateSerialNumberRequestShouldMapToPersistence()
        {
            var source = new PosTracActivateSerialNumberRequest
            {
                TerminalSerialNumber = "12345",
                TerminalVendor = PosTracTerminalVendor.Ingenico
            };

            var actual = this.mapper.Map<ActivateSerialNumberRequest>(source);

            actual.TerminalSerialNumber.Should().Be("12345");
            actual.TerminalVendor.Should().Be(TerminalVendor.Ingenico);
        }

        [Fact]
        public void AdministrationActivateTerminalIdRequestShouldMapToPersistence()
        {
            var source = new PosTracActivateTerminalIdRequest
            {
                TerminalId = "12"
            };

            var actual = this.mapper.Map<ActivateTerminalIdRequest>(source);

            actual.TerminalId.Should().Be("12");
        }

        [Fact]
        public void AdministrationDeactivateRequestShouldMapToPersistence()
        {
            var source = new PosTracDeactivateRequest
            {
                TerminalId = "12"
            };

            var actual = this.mapper.Map<DeactivateRequest>(source);

            actual.TerminalId.Should().Be("12");
        }

        [Fact]
        public void AdministrationRotateCodeRequestShouldMapToPersistence()
        {
            var source = new PosTracRotateCodeRequest
            {
                TerminalId = "12"
            };

            var actual = this.mapper.Map<RotateCodeRequest>(source);

            actual.TerminalId.Should().Be("12");
        }

        [Fact]
        public void AdministrationTerminalIdRequestShouldMapToPersistence()
        {
            var source = new PosTracTerminalIdRequest
            {
                TerminalSerialNumber = "1234",
                TerminalVendor = PosTracTerminalVendor.Ingenico
            };

            var actual = this.mapper.Map<TerminalIdRequest>(source);

            actual.TerminalSerialNumber.Should().Be("1234");
            actual.TerminalVendor.Should().Be(TerminalVendor.Ingenico);
        }

        [Fact]
        public void AllAdministrationActivateStatusEnumsShouldMapToPersistenceEnums()
        {
            var enums = Enum.GetValues(typeof(PosTracActivateStatus)).Cast<PosTracActivateStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<ActivateStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllAdministrationDeactivateStatusEnumsShouldMapToPersistenceEnums()
        {
            var enums = Enum.GetValues(typeof(PosTracDeactivateStatus)).Cast<PosTracDeactivateStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<DeactivateStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllAdministrationFindStatusEnumsShouldMapToPersistenceEnums()
        {
            var enums = Enum.GetValues(typeof(PosTracFindStatus)).Cast<PosTracFindStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<FindStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllAdministrationRotateCodeStatusEnumsShouldMapToPersistenceEnums()
        {
            var enums = Enum.GetValues(typeof(PosTracRotateCodeStatus)).Cast<PosTracRotateCodeStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<RotateCodeStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllAdministrationTerminalVendorEnumsShouldMapToPersistenceEnums()
        {
            var enums = Enum.GetValues(typeof(PosTracTerminalVendor)).Cast<PosTracTerminalVendor>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<TerminalVendor>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllMappersShouldValidate() => this.mapper.ConfigurationProvider.AssertConfigurationIsValid();

        [Fact]
        public void AllPersistenceActivateStatusEnumsShouldMapToAdministrationEnums()
        {
            var enums = Enum.GetValues(typeof(ActivateStatus)).Cast<ActivateStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<PosTracActivateStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllPersistenceDeactivateStatusEnumsShouldMapToAdministrationEnums()
        {
            var enums = Enum.GetValues(typeof(DeactivateStatus)).Cast<DeactivateStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<PosTracDeactivateStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllPersistenceFindStatusEnumsShouldMapToAdministrationEnums()
        {
            var enums = Enum.GetValues(typeof(FindStatus)).Cast<FindStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<PosTracFindStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllPersistenceRotateCodeStatusEnumsShouldMapToAdministrationEnums()
        {
            var enums = Enum.GetValues(typeof(RotateCodeStatus)).Cast<RotateCodeStatus>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<PosTracRotateCodeStatus>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void AllPersistenceTerminalVendorEnumsShouldMapToAdministrationEnums()
        {
            var enums = Enum.GetValues(typeof(TerminalVendor)).Cast<TerminalVendor>().ToList();
            var expectedValues = new Dictionary<int, string>();
            var actualValues = new Dictionary<int, string>();

            foreach (var expected in enums)
            {
                var actual = this.mapper.Map<PosTracTerminalVendor>(expected);

                actualValues.Add((int)actual, actual.ToString());
                expectedValues.Add((int)expected, expected.ToString());
            }

            actualValues.Should().BeEquivalentTo(expectedValues);
        }

        [Fact]
        public void PersistenceActivateReplyShouldMapToAdministration()
        {
            var source = new ActivateReply
            {
                Status = ActivateStatus.Ok,
                TerminalId = "12"
            };

            var actual = this.mapper.Map<PosTracActivateReply>(source);

            actual.Status.Should().Be(PosTracActivateStatus.Ok);
            actual.TerminalId.Should().Be("12");
        }

        [Fact]
        public void PersistenceDeactivateReplyShouldMapToAdministration()
        {
            var source = new DeactivateReply
            {
                Status = DeactivateStatus.Ok
            };

            var actual = this.mapper.Map<PosTracDeactivateReply>(source);

            actual.Status.Should().Be(PosTracDeactivateStatus.Ok);
        }

        [Fact]
        public void PersistenceRotateCodeReplyShouldMapToAdministration()
        {
            var source = new RotateCodeReply
            {
                ActivationCode = "ASD1234",
                Status = RotateCodeStatus.Ok
            };

            var actual = this.mapper.Map<PosTracRotateCodeReply>(source);

            actual.ActivationCode.Should().Be("ASD1234");
            actual.Status.Should().Be(PosTracRotateCodeStatus.Ok);
        }

        [Fact]
        public void PersistenceTerminalIdReplyShouldMapToAdministration()
        {
            var source = new TerminalIdReply
            {
                TerminalId = "12",
                Status = FindStatus.Ok
            };

            var actual = this.mapper.Map<PosTracTerminalIdReply>(source);

            actual.TerminalId.Should().Be("12");
            actual.Status.Should().Be(PosTracFindStatus.Ok);
        }
    }
}