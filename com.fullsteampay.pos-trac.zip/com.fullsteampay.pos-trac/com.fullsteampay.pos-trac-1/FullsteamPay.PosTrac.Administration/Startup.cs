﻿namespace FullsteamPay.PosTrac.Administration
{
    using System;
    using FullsteamPay.PosTrac.Administration.Services;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// Represents the bootstrapper for initializing configuration and services for the terminal control service.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup" /> class.
        /// </summary>
        /// <param name="environment">
        /// Provides information about the web hosting environment in which the application is running.
        /// </param>
        public Startup(IWebHostEnvironment environment)
        {
            this.CurrentEnvironment = environment ?? throw new ArgumentNullException(nameof(environment));
        }

        /// <summary>
        /// Gets an object that provides information about the web hosting environment in which the application is running.
        /// </summary>
        /// <value>
        /// An object that provides information about the web hosting environment in which the application is running.
        /// </value>
        public IWebHostEnvironment CurrentEnvironment { get; }

        /// <summary>
        /// Configure the HTTP request pipeline. This method is called by the runtime.
        /// </summary>
        /// <param name="app">Provides the mechanisms to configure the applications request pipeline.</param>
        public void Configure(IApplicationBuilder app)
        {
            if (this.CurrentEnvironment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGrpcService<TerminalAdministrationService>();

                if (this.CurrentEnvironment.IsDevelopment())
                {
                    endpoints.MapGrpcReflectionService();
                }

                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync(Strings.GrpcUnsupportedRequest);
                });
            });
        }

        /// <summary>
        /// Configure services in the dependency injection container. This method is called by the runtime.
        /// </summary>
        /// <param name="services">The collection of dependency injection service descriptors for the application.</param>
        /// <remarks>For more information on how to configure your application, visit <a href="https://go.microsoft.com/fwlink/?LinkID=398940" />.</remarks>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetry();

            // These options are added to the service collection here instead of in AddPersistenceGrpcClient because
            // that method can be called multiple times, and we do not want to register the options each time we do
            // that. As far as I am aware, there is no TryAddOptions method that would smooth over that particular problem.
            services.AddOptions<PersistenceGrpcClientOptions>().BindConfiguration(PersistenceGrpcClientOptions.SectionName);
            services.AddGrpc();

            // The EnableCallContextPropagation() pushes both the deadline (timeout) and cancellation received on the
            // server side on to the client. This means that if the client connecting to this service times out or
            // receives a cancellation, any calls this service itself made out to other gRPC services receive the same
            // treatment. So a call on the server side that is cancelled is also cancelled on the client side. For more
            // information, see https://docs.microsoft.com/en-us/aspnet/core/grpc/deadlines-cancellation?view=aspnetcore-5.0
            services.AddPersistenceGrpcClient<TerminalData.TerminalDataClient>().EnableCallContextPropagation();

            if (this.CurrentEnvironment.IsDevelopment())
            {
                services.AddGrpcReflection();
            }

            services.AddAutoMapper(typeof(TerminalAdministrationProfile));
            services.AddRedis();
        }
    }
}