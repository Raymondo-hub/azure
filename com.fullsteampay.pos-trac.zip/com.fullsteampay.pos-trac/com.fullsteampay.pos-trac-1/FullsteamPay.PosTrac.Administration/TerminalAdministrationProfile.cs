﻿namespace FullsteamPay.PosTrac.Administration
{
    using AutoMapper;
    using FullsteamPay.PosTrac.Administration.Protos;
    using FullsteamPay.PosTrac.Persistence.Protos;

    /// <summary>
    /// Defines an AutoMapper configuration profile for mapping between terminal administration objects.
    /// </summary>
    public class TerminalAdministrationProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalAdministrationProfile" /> class.
        /// </summary>
        public TerminalAdministrationProfile()
        {
            this.CreateMap<ActivateReply, PosTracActivateReply>();
            this.CreateMap<DeactivateReply, PosTracDeactivateReply>();
            this.CreateMap<PosTracActivateActivationCodeRequest, ActivateActivationCodeRequest>();
            this.CreateMap<PosTracActivateSerialNumberRequest, ActivateSerialNumberRequest>();
            this.CreateMap<PosTracActivateTerminalIdRequest, ActivateTerminalIdRequest>();
            this.CreateMap<PosTracDeactivateRequest, DeactivateRequest>();
            this.CreateMap<PosTracRotateCodeRequest, RotateCodeRequest>();
            this.CreateMap<PosTracTerminalIdRequest, TerminalIdRequest>();
            this.CreateMap<RotateCodeReply, PosTracRotateCodeReply>();
            this.CreateMap<TerminalIdReply, PosTracTerminalIdReply>();
        }
    }
}