﻿namespace FullsteamPay.PosTrac.Administration.Services
{
    using System;
    using System.Globalization;
    using System.Text.Json;
    using System.Threading.Tasks;
    using AutoMapper;
    using FullsteamPay.PosTrac.Administration.Protos;
    using FullsteamPay.PosTrac.Domain.Ingenico;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using FullsteamPay.PosTrac.Web;
    using Grpc.Core;
    using Microsoft.Extensions.Logging;
    using StackExchange.Redis;

    /// <summary>
    /// The gRPC service that performs administrative tasks for and about terminals.
    /// </summary>
    public class TerminalAdministrationService : TerminalAdministration.TerminalAdministrationBase
    {
        /// <summary>
        /// The redis client for interacting with pub-sub messaging capabilites to the broker service.
        /// </summary>
        private readonly ISubscriber broker;

        /// <summary>
        /// The gRPC client for interacting with terminal registration persistence.
        /// </summary>
        private readonly TerminalData.TerminalDataClient client;

        /// <summary>
        /// The logger for this component.
        /// </summary>
        private readonly ILogger<TerminalAdministrationService> logger;

        /// <summary>
        /// The mapper used to map between different objects.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalAdministrationService" /> class.
        /// </summary>
        /// <param name="client">The gRPC client for interacting with terminal registration persistence.</param>
        /// <param name="multiplexer">The connection multiplexer for accessing the redis service.</param>
        /// <param name="mapper">The mapper used to map between different objects.</param>
        /// <param name="logger">The logger for this component.</param>
        public TerminalAdministrationService(TerminalData.TerminalDataClient client, IConnectionMultiplexer multiplexer, IMapper mapper, ILogger<TerminalAdministrationService> logger)
        {
            if (multiplexer is null)
            {
                throw new ArgumentNullException(nameof(multiplexer));
            }

            this.client = client ?? throw new ArgumentNullException(nameof(client));
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.broker = multiplexer.GetSubscriber();
        }

        /// <inheritdoc />
        public override async Task<PosTracActivateReply> ActivateByActivationCode(PosTracActivateActivationCodeRequest request, ServerCallContext context)
        {
            var reply = await this.ProxyToPersistence<PosTracActivateActivationCodeRequest, ActivateActivationCodeRequest, ActivateReply, PosTracActivateReply>(
                $"Activating terminal for activation code {request.ActivationCode}.",
                request,
                r => this.client.ActivateByActivationCodeAsync(r));

            await this.SendActivationToBrokerAsync(reply.TerminalId);

            return reply;
        }

        /// <inheritdoc />
        public override async Task<PosTracActivateReply> ActivateBySerialNumber(PosTracActivateSerialNumberRequest request, ServerCallContext context)
        {
            var reply = await this.ProxyToPersistence<PosTracActivateSerialNumberRequest, ActivateSerialNumberRequest, ActivateReply, PosTracActivateReply>(
                $"Activating terminal for TSN #{request.TerminalSerialNumber} and vendor {request.TerminalVendor}.",
                request,
                r => this.client.ActivateBySerialNumberAsync(r));

            await this.SendActivationToBrokerAsync(reply.TerminalId);

            return reply;
        }

        /// <inheritdoc />
        public override async Task<PosTracActivateReply> ActivateByTerminalId(PosTracActivateTerminalIdRequest request, ServerCallContext context)
        {
            var reply = await this.ProxyToPersistence<PosTracActivateTerminalIdRequest, ActivateTerminalIdRequest, ActivateReply, PosTracActivateReply>(
                $"Activating terminal for ID {request.TerminalId}.",
                request,
                r => this.client.ActivateByTerminalIdAsync(r));

            await this.SendActivationToBrokerAsync(reply.TerminalId);

            return reply;
        }

        /// <inheritdoc />
        public override async Task<PosTracDeactivateReply> Deactivate(PosTracDeactivateRequest request, ServerCallContext context)
        {
            return await this.ProxyToPersistence<PosTracDeactivateRequest, DeactivateRequest, DeactivateReply, PosTracDeactivateReply>(
                $"Deactivating terminal for terminal identifier {request.TerminalId}.",
                request,
                r => this.client.DeactivateAsync(r));
        }

        /// <inheritdoc />
        public override async Task<PosTracTerminalIdReply> GetTerminalId(PosTracTerminalIdRequest request, ServerCallContext context)
        {
            return await this.ProxyToPersistence<PosTracTerminalIdRequest, TerminalIdRequest, TerminalIdReply, PosTracTerminalIdReply>(
                $"Getting terminal identifier for TSN #{request.TerminalSerialNumber} and vendor {request.TerminalVendor}.",
                request,
                d => this.client.GetTerminalIdAsync(d));
        }

        /// <inheritdoc />
        public override async Task<PosTracRotateCodeReply> RotateActivationCode(PosTracRotateCodeRequest request, ServerCallContext context)
        {
            var reply = await this.ProxyToPersistence<PosTracRotateCodeRequest, RotateCodeRequest, RotateCodeReply, PosTracRotateCodeReply>(
                $"Manually rotating activation code for terminal ID {request.TerminalId}.",
                request,
                d => this.client.RotateCodeAsync(d));

            if (!string.IsNullOrEmpty(reply.ActivationCode) && reply.Status == PosTracRotateCodeStatus.Ok)
            {
                await this.SendCodeRotationToBrokerAsync(request.TerminalId, reply.ActivationCode);
            }

            return reply;
        }

        /// <summary>
        /// Formats and returns the name of the redis channel that sends to the broker for the specified terminal.
        /// </summary>
        /// <param name="terminalId">The identifier of the terminal.</param>
        /// <returns>The formatted redis channel name.</returns>
        private static string FormatRedisBrokerSubscriberChannelName(string terminalId)
            => string.Format(CultureInfo.InvariantCulture, Constants.RedisBrokerSubscriberChannelNameFormat, terminalId.ToNormalizedIdentifier());

        /// <summary>
        /// Performs the work of mapping and forwarding an incoming request to the persistence service in order to
        /// complete certain types of administrative functions.
        /// </summary>
        /// <typeparam name="TAdminRequest">The type of the request to the administration service.</typeparam>
        /// <typeparam name="TDataRequest">The type of the request to the data persistence service.</typeparam>
        /// <typeparam name="TDataReply">The type of the reply from the data persistence service.</typeparam>
        /// <typeparam name="TAdminReply">The type of the reply from the administration service.</typeparam>
        /// <param name="debugMessage">The message to debug log about this service method.</param>
        /// <param name="request">The original request coming into the administration service.</param>
        /// <param name="action">The function to execute after the initial mapping.</param>
        /// <returns>The reply to return back for the original request.</returns>
        private async Task<TAdminReply> ProxyToPersistence<TAdminRequest, TDataRequest, TDataReply, TAdminReply>(
            string debugMessage,
            TAdminRequest request,
            Func<TDataRequest, AsyncUnaryCall<TDataReply>> action)
        {
            this.logger.LogInformation(debugMessage);

            var dataRequest = this.mapper.Map<TDataRequest>(request);
            var dataResponse = await action(dataRequest);

            return this.mapper.Map<TAdminReply>(dataResponse);
        }

        /// <summary>
        /// Sends a "terminal activated" message to the broker to display on the terminal.
        /// </summary>
        /// <param name="terminalId">The identifier of the terminal.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private Task SendActivationToBrokerAsync(string terminalId)
        {
            var channelName = FormatRedisBrokerSubscriberChannelName(terminalId);

            return this.SendFormMessageToBrokerAsync(FormMessage.CreateStandardTerminalActivatedForm(), channelName);
        }

        /// <summary>
        /// Sends an "activation code" message to the broker to display on the terminal.
        /// </summary>
        /// <param name="terminalId">The identifier of the terminal to notify.</param>
        /// <param name="activationCode">The new activation code to display on the terminal.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private Task SendCodeRotationToBrokerAsync(string terminalId, string activationCode)
        {
            var channelName = FormatRedisBrokerSubscriberChannelName(terminalId);

            return this.SendFormMessageToBrokerAsync(FormMessage.CreateStandardActivationForm(activationCode), channelName);
        }

        /// <summary>
        /// Sends an Ingenico <see cref="FormMessage" /> object to be published to the broker for the specified channel.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="channelName">The redis channel to which to publish the message.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private Task SendFormMessageToBrokerAsync(FormMessage message, string channelName)
        {
            // TODO: This is strongly tied to Ingenico, probably need to find a way to decouple.
            var formBytes = JsonSerializer.SerializeToUtf8Bytes(message, IngenicoJsonSerializerOptions.GetDefaultOptions());

            return this.broker.PublishAsync(channelName, formBytes);
        }
    }
}