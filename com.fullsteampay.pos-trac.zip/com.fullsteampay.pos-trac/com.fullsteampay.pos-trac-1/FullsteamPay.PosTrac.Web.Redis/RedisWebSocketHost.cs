﻿namespace FullsteamPay.PosTrac.Web.Redis
{
    using System;
    using System.Globalization;
    using System.Net.WebSockets;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    using StackExchange.Redis;

    /// <summary>
    /// Represents a implementation of a web socket host that uses the redis publsiher/subscriber message distribution
    /// mechanism to pass messages to another service.
    /// </summary>
    public abstract class RedisWebSocketHost : BaseWebSocketHost
    {
        /// <summary>
        /// The name of the redis pub/sub channel used to publish for this client.
        /// </summary>
        private string publishingChannelName = string.Empty;

        /// <summary>
        /// A value indicating whether the publisher channel name is dirty and should be re-generated on next access.
        /// </summary>
        private bool publishingChannelNameIsDirty = true;

        /// <summary>
        /// The name of redis pub/sub channel used to subscribe for this client.
        /// </summary>
        private string subscribingChannelName = string.Empty;

        /// <summary>
        /// A value indicating whether the subscribing channel name is dirty and should be re-generated on next access.
        /// </summary>
        private bool subscribingChannelNameIsDirty = true;

        /// <summary>
        /// Initializes a new instance of the <see cref="RedisWebSocketHost" /> class.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <param name="multiplexer">The connection multiplexer for accessing the redis service.</param>
        /// <param name="logger">The logger for this component.</param>
        protected RedisWebSocketHost(
            WebSocket socket,
            string socketClientId,
            IConnectionMultiplexer multiplexer,
            ILogger logger)
            : base(socket, socketClientId, logger)
        {
            if (multiplexer is null)
            {
                throw new ArgumentNullException(nameof(multiplexer));
            }

            if (string.IsNullOrWhiteSpace(socketClientId))
            {
                throw new ArgumentNullException(nameof(socketClientId));
            }

            this.Subscriber = multiplexer.GetSubscriber();
        }

        /// <inheritdoc />
        public override string? SocketClientId
        {
            get => base.SocketClientId;
            protected set
            {
                this.publishingChannelNameIsDirty = true;
                this.subscribingChannelNameIsDirty = true;
                base.SocketClientId = value;
            }
        }

        /// <summary>
        /// Gets the subscriber connection to the redis publsiher/subscriber message distribution mechanism for this client.
        /// </summary>
        public ISubscriber Subscriber { get; }

        /// <summary>
        /// Gets the name of the redis pub/sub channel used to publish for this client.
        /// </summary>
        /// <value>The name of the redis pub/sub channel used to publish for this client.</value>
        protected string PublishingChannelName
        {
            get
            {
                if (this.publishingChannelNameIsDirty)
                {
                    this.publishingChannelName = string.Format(CultureInfo.InvariantCulture, this.PublishingChannelNameFormat, this.SocketClientId);
                    this.publishingChannelNameIsDirty = false;
                }

                return this.publishingChannelName;
            }
        }

        /// <summary>
        /// Gets the format string used to build the name of the redis publishing channel for this client.
        /// </summary>
        /// <value>The format string used to build the name of the redis publishing channel for this client.</value>
        protected abstract string PublishingChannelNameFormat { get; }

        /// <summary>
        /// Gets the name of redis pub/sub channel used to subscribe for this client.
        /// </summary>
        /// <value>The name of redis pub/sub channel used to subscribe for this client.</value>
        protected string SubscribingChannelName
        {
            get
            {
                if (this.subscribingChannelNameIsDirty)
                {
                    this.subscribingChannelName = string.Format(CultureInfo.InvariantCulture, this.SubscribingChannelNameFormat, this.SocketClientId);
                    this.subscribingChannelNameIsDirty = false;
                }

                return this.subscribingChannelName;
            }
        }

        /// <summary>
        /// Gets the format string used to build the name of the redis subscribing channel for this client.
        /// </summary>
        /// <value>The format string used to build the name of the redis subscribing channel for this client.</value>
        protected abstract string SubscribingChannelNameFormat { get; }

        /// <inheritdoc />
        public override async Task SetupAsync()
        {
            await base.SetupAsync();

            var handler = await this.Subscriber.SubscribeAsync(this.SubscribingChannelName);

            handler.OnMessage(this.ProcessSubscriberMessageAsync);
        }

        /// <summary>
        /// Delegate used to process messages received from the subscribed redis publishing channel.
        /// </summary>
        /// <param name="message">The message received from the subscribed channel.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        protected abstract Task ProcessSubscriberMessageAsync(ChannelMessage message);
    }
}