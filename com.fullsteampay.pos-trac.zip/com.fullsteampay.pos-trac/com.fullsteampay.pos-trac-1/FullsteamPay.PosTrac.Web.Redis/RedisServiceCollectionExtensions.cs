﻿namespace Microsoft.Extensions.DependencyInjection
{
    using System;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Framework;
    using Microsoft.Extensions.Options;
    using StackExchange.Redis;

    /// <summary>
    /// Extension methods for setting up services in the dependency injection container.
    /// </summary>
    public static class RedisServiceCollectionExtensions
    {
        /// <summary>
        /// Adds redis services to the <paramref name="services" /> container.
        /// </summary>
        /// <param name="services">The current collection of dependency injection services.</param>
        /// <returns>A collection of dependency injection services.</returns>
        public static IServiceCollection AddRedis(this IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            services.AddOptions<RedisClientOptions>().BindConfiguration(RedisClientOptions.SectionName);
            services.AddSingleton(CreateConnectionMultiplexer);

            return services;
        }

        /// <summary>
        /// A factory method delegate for creating the Stack Exchange redis multiplexer.
        /// </summary>
        /// <param name="provider">The dependency injection service provider for resolving any needed configuration.</param>
        /// <returns>An abstract multiplexer API for a redis client.</returns>
        private static IConnectionMultiplexer CreateConnectionMultiplexer(IServiceProvider provider)
        {
            var options = provider.GetService<IOptions<RedisClientOptions>>();

            if (options is null)
            {
                throw new InvalidOperationException(Strings.RedisClientConfigurationNotRegistered);
            }

            if (string.IsNullOrWhiteSpace(options.Value.ServiceEndpoint))
            {
                throw new InvalidOperationException(Strings.RedisClientServiceEndpointNotConfigured);
            }

            return ConnectionMultiplexer.Connect(options.Value.ServiceEndpoint);
        }
    }
}