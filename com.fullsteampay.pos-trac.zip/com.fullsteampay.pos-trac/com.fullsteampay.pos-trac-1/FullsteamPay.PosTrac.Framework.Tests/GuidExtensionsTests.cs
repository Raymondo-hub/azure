﻿namespace FullsteamPay.PosTrac.Framework.Tests
{
    using System;
    using FluentAssertions;
    using Xunit;

    public sealed class GuidExtensionsTests
    {
        public static TheoryData<Guid, string> GuidIdentifierValues
            => new()
            {
                { Guid.Empty, "00000000000000000000000000000000" },
                { new Guid("ee159183-7227-43d9-a29f-be3d1be282bc"), "ee159183722743d9a29fbe3d1be282bc" },
                { new Guid("EE159183-7227-43D9-A29f-BE3D1BE282BC"), "ee159183722743d9a29fbe3d1be282bc" },
                { Guid.Parse("EE159183-7227-43D9-A29f-BE3D1BE282BC"), "ee159183722743d9a29fbe3d1be282bc" }
            };

        [Theory]
        [MemberData(nameof(GuidIdentifierValues))]
        public void ToNormalizedIdentifierShouldReturnCorrectOutput(Guid input, string expected) => GuidExtensions.ToNormalizedIdentifier(input).Should().Be(expected);
    }
}