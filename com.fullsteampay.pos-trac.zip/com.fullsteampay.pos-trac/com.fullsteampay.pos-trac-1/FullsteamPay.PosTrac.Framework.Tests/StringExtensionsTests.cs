﻿namespace FullsteamPay.PosTrac.Framework.Tests
{
    using FluentAssertions;
    using Xunit;

    public sealed class StringExtensionsTests
    {
        public static TheoryData<string, string> KebabCaseValues
            => new()
            {
                { "URLValue", "url-value" },
                { "URL", "url" },
                { "ID", "id" },
                { "I", "i" },
                { "Person", "person" },
                { "iPhone", "i-phone" },
                { "IPhone", "i-phone" },
                { "I Phone", "i-phone" },
                { "I  Phone", "i-phone" },
                { " IPhone", "i-phone" },
                { " IPhone ", "i-phone" },
                { "IsCIA", "is-cia" },
                { "VmQ", "vm-q" },
                { "Xml2Json", "xml2-json" },
                { "KeBaBcAsE", "ke-ba-bc-as-e" },
                { "KeB--aBcAsE", "ke-b--a-bc-as-e" },
                { "KeB-- aBcAsE", "ke-b--a-bc-as-e" },
                { "already-kebab-case- ", "already-kebab-case-" },
                { "IsJSONProperty", "is-json-property" },
                { "SHOUTING-CASE", "shouting-case" },
                { "9999-12-31T23:59:59.9999999Z", "9999-12-31-t23:59:59.9999999-z" },
                { "Hi!! This is text. Time to test.", "hi!!-this-is-text.-time-to-test." }
            };

        public static TheoryData<string, string> LowerInvariantFirstCharacterValues
            => new()
            {
                { "PropertyName", "propertyName" },
                { "propertyName", "propertyName" },
                { "_Property", "_Property" },
                { "_property", "_property" },
                { "PROPERTYNAME", "pROPERTYNAME" },
                { " ", " " },
                { " PropertyName ", " PropertyName " }
            };

        public static TheoryData<string, string> NormalizedIdentifierValues
            => new()
            {
                { " ", string.Empty },
                { "   \n\t\t\t\n", string.Empty },
                { "identifier12345", "identifier12345" },
                { "Identifier12345", "identifier12345" },
                { "IDENTIFIER12345", "identifier12345" },
                { "identIFIER12345A", "identifier12345a" },
                { "  IDENTIFIER12345  ", "identifier12345" },
                { "  \t\n   IDENTIFIER12345  \n\n", "identifier12345" },
                { "  \t\n   IDENTI   \n\tFIER12345  \n\n", "identifier12345" }
            };

        public static TheoryData<string, string> SnakeCaseValues
                    => new()
                    {
                        { "URLValue", "url_value" },
                        { "URL", "url" },
                        { "ID", "id" },
                        { "I", "i" },
                        { "Person", "person" },
                        { "iPhone", "i_phone" },
                        { "IPhone", "i_phone" },
                        { "I Phone", "i_phone" },
                        { "I  Phone", "i_phone" },
                        { " IPhone", "i_phone" },
                        { " IPhone ", "i_phone" },
                        { "IsCIA", "is_cia" },
                        { "VmQ", "vm_q" },
                        { "Xml2Json", "xml2_json" },
                        { "SnAkEcAsE", "sn_ak_ec_as_e" },
                        { "SnA__kEcAsE", "sn_a__k_ec_as_e" },
                        { "SnA__ kEcAsE", "sn_a__k_ec_as_e" },
                        { "already_snake_case_ ", "already_snake_case_" },
                        { "IsJSONProperty", "is_json_property" },
                        { "SHOUTING_CASE", "shouting_case" },
                        { "9999-12-31T23:59:59.9999999Z", "9999-12-31_t23:59:59.9999999_z" },
                        { "Hi!! This is text. Time to test.", "hi!!_this_is_text._time_to_test." }
                    };

        [Theory]
        [MemberData(nameof(KebabCaseValues))]
        public void ToKebabCaseShouldReturnCorrectOutput(string input, string expected) => StringExtensions.ToKebabCase(input).Should().Be(expected);

        [Fact]
        public void ToKebabCaseWithEmptyInputShouldReturnEmpty() => StringExtensions.ToSnakeCase(string.Empty).Should().BeEmpty();

        [Fact]
        public void ToKebabCaseWithNullInputShouldReturnNull() => StringExtensions.ToSnakeCase(null).Should().BeNull();

        [Theory]
        [MemberData(nameof(LowerInvariantFirstCharacterValues))]
        public void ToLowerInvariantFirstCharacterShouldReturnCorrectOutput(string input, string expected) => StringExtensions.ToLowerInvariantFirstCharacter(input).Should().Be(expected);

        [Fact]
        public void ToLowerInvariantFirstCharacterWithEmptyIntputShouldReturnEmpty() => StringExtensions.ToLowerInvariantFirstCharacter(string.Empty).Should().BeEmpty();

        [Fact]
        public void ToLowerInvariantFirstCharacterWithNullInputShouldReturnNull() => StringExtensions.ToLowerInvariantFirstCharacter(null).Should().BeNull();

        [Theory]
        [MemberData(nameof(NormalizedIdentifierValues))]
        public void ToNormalizedIdentifierShouldReturnCorrectOutput(string input, string expected) => StringExtensions.ToNormalizedIdentifier(input).Should().Be(expected);

        [Fact]
        public void ToNormalizedIdentifierWithEmptyInputShouldReturnEmpty() => StringExtensions.ToNormalizedIdentifier(string.Empty).Should().BeEmpty();

        [Fact]
        public void ToNormalizedIdentifierWithNullInputShouldReturnNull() => StringExtensions.ToNormalizedIdentifier(null).Should().BeEmpty();

        [Theory]
        [MemberData(nameof(SnakeCaseValues))]
        public void ToSnakeCaseShouldReturnCorrectOutput(string input, string expected) => StringExtensions.ToSnakeCase(input).Should().Be(expected);

        [Fact]
        public void ToSnakeCaseWithEmptyInputShouldReturnEmpty() => StringExtensions.ToSnakeCase(string.Empty).Should().BeEmpty();

        [Fact]
        public void ToSnakeCaseWithNullInputShouldReturnNull() => StringExtensions.ToSnakeCase(null).Should().BeNull();
    }
}