﻿namespace FullsteamPay.PosTrac.Framework.Tests
{
    using System;
    using System.Text.Json;
    using FluentAssertions;
    using Xunit;

    public sealed class JsonSnakeCaseNamingPolicyIntegrationTests
    {
        private readonly JsonSerializerOptions snakeCaseOptions = new() { PropertyNamingPolicy = new JsonSnakeCaseNamingPolicy() };

        private static TestPerson Person
            => new()
            {
                Name = "Timmy Test",
                BirthDate = new DateTime(1999, 12, 31),
                LastAccessedIPAddress = "1.1.1.1",
                SsnOnFile = "555-55-5555"
            };

        private static string TestPersonJson => @"{""birth_date"":""1999-12-31T00:00:00"",""last_accessed_ip_address"":""1.1.1.1"",""name"":""Timmy Test"",""ssn_on_file"":""555-55-5555""}";

        [Fact]
        public void JsonSnakeCaseNamingPolicyShouldDeserializeCorrectly()
        {
            var actual = JsonSerializer.Deserialize<TestPerson>(TestPersonJson, this.snakeCaseOptions);

            actual.Should().BeEquivalentTo(Person);
        }

        [Fact]
        public void JsonSnakeCaseNamingPolicyShouldSerializeCorrectly()
        {
            var actual = JsonSerializer.Serialize(Person, this.snakeCaseOptions);

            actual.Should().Be(TestPersonJson);
        }
    }
}