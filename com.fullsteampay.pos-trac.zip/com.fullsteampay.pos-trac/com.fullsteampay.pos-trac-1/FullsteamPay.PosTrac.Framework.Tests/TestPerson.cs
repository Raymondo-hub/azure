﻿namespace FullsteamPay.PosTrac.Framework.Tests
{
    using System;

    internal sealed class TestPerson
    {
        public DateTime BirthDate { get; set; }

        public string LastAccessedIPAddress { get; set; }

        public string Name { get; set; }

        public string SsnOnFile { get; set; }
    }
}