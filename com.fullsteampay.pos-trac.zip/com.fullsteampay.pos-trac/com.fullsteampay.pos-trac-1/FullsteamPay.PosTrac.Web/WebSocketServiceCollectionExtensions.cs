﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using Microsoft.Extensions.DependencyInjection;

    /// <summary>
    /// Extension methods for setting up the basic web sockets hosts in the dependency injection container.
    /// </summary>
    public static class WebSocketServiceCollectionExtensions
    {
        /// <summary>
        /// Adds web socket host and middleware services to the <paramref name="services" /> container.
        /// </summary>
        /// <typeparam name="THost">The type to build with the web socket host factory.</typeparam>
        /// <param name="services">The current collection of dependency injection services.</param>
        /// <returns>A collection of dependency injection services.</returns>
        public static IServiceCollection AddWebSocketHostMiddleware<THost>(this IServiceCollection services)
            where THost : IWebSocketHost
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            services.AddSingleton<IConnectionManifest, DefaultConnectionManifest>();
            services.AddSingleton<IWebSocketHostFactory, DefaultWebSocketHostFactory<THost>>();
            services.AddScoped<WebSocketHostMiddleware>();

            return services;
        }
    }
}