﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using System.Buffers;
    using System.IO.Pipelines;
    using System.Net;
    using System.Net.WebSockets;
    using System.Threading;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Represents middleware that accepts web socket requests and uses <see cref="IWebSocketHost" /> to control
    /// interaction with the socket.
    /// </summary>
    public class WebSocketHostMiddleware : IMiddleware
    {
        /// <summary>
        /// The factory used to create clients for interacting with the socket.
        /// </summary>
        private readonly IWebSocketHostFactory factory;

        /// <summary>
        /// The logger for this middleware.
        /// </summary>
        private readonly ILogger<WebSocketHostMiddleware> logger;

        /// <summary>
        /// The manifest of hosts currently active for the whole service.
        /// </summary>
        private readonly IConnectionManifest manifest;

        /// <summary>
        /// Initializes a new instance of the <see cref="WebSocketHostMiddleware" /> class.
        /// </summary>
        /// <param name="manifest">The manifest of hosts currently active for the whole service.</param>
        /// <param name="factory">The factory used to create clients for interacting with the socket.</param>
        /// <param name="logger">The logger for this middleware.</param>
        public WebSocketHostMiddleware(IConnectionManifest manifest, IWebSocketHostFactory factory, ILogger<WebSocketHostMiddleware> logger)
        {
            this.manifest = manifest ?? throw new ArgumentNullException(nameof(manifest));
            this.factory = factory ?? throw new ArgumentNullException(nameof(factory));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc />
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                if (!this.manifest.IsServerRunning)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.Conflict;
                    await context.Response.StartAsync();

                    return;
                }

                if (!context.WebSockets.IsWebSocketRequest)
                {
                    // Ignore all other requests, although potentially other middleware will handle it. We can still log
                    // the fact that we saw it however.
                    this.logger.LogInformation("Ignoring non-websocket request.");

                    return;
                }

                // This probably needs some work to account for edge cases. The routing is currently specified as
                // required so a 404 is returned when no client ID is specifed in the hosts where routing is enabled.
                var socketClientId = GetSocketClientIdFromRequest(context);
                var socket = await context.WebSockets.AcceptWebSocketAsync();

                // In the future, there will probably be a layer here to determine the correct client to use.
                var client = this.factory.CreateHost(socket, socketClientId);

                await client.SetupAsync();

                this.manifest.Hosts.TryAdd(client.SocketId, client);
                this.logger.LogInformation($"Socket {client.SocketId}: New connection.");

                // Perform any work that needs to happen immediately after the web socket connects.
                await client.ProcessConnectionOpenedAsync();

                // TaskCompletionSource<> is used to keep the middleware pipeline alive; SocketProcessingLoop calls
                // TrySetResult upon socket termination.
                _ = Task.Run(() => this.SocketProcessingLoopAsync(client).ConfigureAwait(false));

                await client.TaskCompletion.Task;
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                this.logger.LogError("There was a problem while accepting the connection.", ex);
            }
            finally
            {
                // If this middleware didn't handle the request, pass it on.
                if (!context.Response.HasStarted)
                {
                    await next(context);
                }
            }
        }

        /// <summary>
        /// Retrieves the socket client identifier from the route values of the request.
        /// </summary>
        /// <param name="context">The request from which to check.</param>
        /// <returns>The socket client identifier.</returns>
        private static string GetSocketClientIdFromRequest(HttpContext context) =>
            context.GetRouteData().Values[Constants.WebSocketClientIdRouteValueKey] is not string clientId
                ? string.Empty
                : clientId.Trim();

        /// <summary>
        /// Reads the host's web socket and fills a <see cref="Pipe" /> with the received data.
        /// </summary>
        /// <param name="host">The host interacting with the web socket.</param>
        /// <param name="writer">The writer to a pipe for storing data.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private async Task FillPipeAsync(IWebSocketHost host, PipeWriter writer)
        {
            var serverToken = this.manifest.SocketLoopTokenSource.Token;
            Exception? error = null;

            try
            {
                while (true)
                {
                    var memory = writer.GetMemory(512);
                    var receiveResult = await host.Socket.ReceiveAsync(memory, serverToken);

                    if (!serverToken.IsCancellationRequested)
                    {
                        if (host.Socket.State == WebSocketState.CloseReceived && receiveResult.MessageType == WebSocketMessageType.Close)
                        {
                            this.logger.LogInformation($"Socket {host.SocketId}: Acknowledging Close frame received from client");

                            // This tells the host (in other words, limited to this one connection) to cancel any tokens
                            // it created.
                            host.BroadcastLoopTokenSource.Cancel();
                            await host.Socket.CloseOutputAsync(WebSocketCloseStatus.NormalClosure, "Acknowledge Close frame", CancellationToken.None);
                        }
                    }

                    if (receiveResult.Count == 0)
                    {
                        break;
                    }

                    this.logger.LogInformation($"Socket {host.SocketId}: Received {receiveResult.MessageType} frame ({receiveResult.Count} bytes).");

                    writer.Advance(receiveResult.Count);

                    var flushResult = await writer.FlushAsync(serverToken);

                    if (flushResult.IsCompleted || receiveResult.EndOfMessage)
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                // TODO: Probably need to revisit the exception this catches.
                this.logger.LogError("There was a problem while writing the websocket received bytes to the message pipe.", ex);

                error = ex;

                // This was not initially here, but I would see some weird behavior here in an integration test where if
                // the other end aborted the connection, this would essentially loop forever getting a connection
                // aborted exception. I'm not sure if this happens in "real" situations or not, but for right now I just
                // want the host to exit if something bad happens. I'm also not terribly sure that we should even catch
                // here honestly; I'm not exactly sure how essential it is to call the .Complete() method before the
                // exception bubbles up.
                throw;
            }
            finally
            {
                writer.Complete(error);
            }
        }

        /// <summary>
        /// Reads the pipe filled with data and sends it to the host to process.
        /// </summary>
        /// <param name="host">The host interacting with the web socket.</param>
        /// <param name="reader">The reader to a pipe that is storing data.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private async Task ReadPipeAsync(IWebSocketHost host, PipeReader reader)
        {
            Exception? error = null;
            byte[]? message = null;
            var serverToken = this.manifest.SocketLoopTokenSource.Token;

            try
            {
                while (true)
                {
                    var result = await reader.ReadAsync(serverToken);
                    var sequence = result.Buffer;

                    if (result.IsCanceled)
                    {
                        break;
                    }

                    if (sequence.IsEmpty && result.IsCompleted)
                    {
                        break;
                    }

                    if (sequence.IsSingleSegment)
                    {
                        // This is the performant path, where a single buffer holds the entire contents of the message
                        // and can be sent immediately onto the backplane.
                        await host.ProcessSocketMessageAsync(sequence.First);
                    }
                    else
                    {
                        // This will throw OverflowException if the sequence length is larger than Int32.MaxValue, but
                        // if that is true we couldn't allocate a Memory<byte> large enough to hold it anyway. So that
                        // should be acceptable.
                        var sequenceLength = checked((int)sequence.Length);
                        message = ArrayPool<byte>.Shared.Rent(sequenceLength);

                        sequence.CopyTo(message);

                        await host.ProcessSocketMessageAsync(message.AsMemory().Slice(0, sequenceLength));

                        ArrayPool<byte>.Shared.Return(message);
                        message = null;
                    }

                    reader.AdvanceTo(sequence.End);
                }
            }
            catch (Exception ex)
            {
                // TODO: Probably need to revisit the exception this catches.
                this.logger.LogError("There was a problem while reading the message pipe.", ex);

                error = ex;

                // This was not initially here, but I would see some weird behavior here in an integration test where if
                // the other end aborted the connection, this would essentially loop forever getting a connection
                // aborted exception. I'm not sure if this happens in "real" situations or not, but for right now I just
                // want the host to exit if something bad happens.
                throw;
            }
            finally
            {
                if (message is not null)
                {
                    ArrayPool<byte>.Shared.Return(message);
                }

                reader.Complete(error);
            }
        }

        /// <summary>
        /// The delegate that listens to the web socket and processes any incoming messages from the client.
        /// </summary>
        /// <param name="host">The host interacting with the web socket.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private async Task SocketProcessingLoopAsync(IWebSocketHost host)
        {
            _ = Task.Run(() => host.BroadcastLoopAsync().ConfigureAwait(false));

            var socket = host.Socket;
            var loopToken = this.manifest.SocketLoopTokenSource.Token;
            var broadcastTokenSource = host.BroadcastLoopTokenSource;

            try
            {
                while (socket.State != WebSocketState.Closed && socket.State != WebSocketState.Aborted && !loopToken.IsCancellationRequested)
                {
                    var pipe = new Pipe();

                    await this.FillPipeAsync(host, pipe.Writer);

                    if (socket.State == WebSocketState.Open)
                    {
                        await this.ReadPipeAsync(host, pipe.Reader);
                    }
                }

                // It might be better to have this in the finally block, but it itself could throw, so we would need to
                // be sure to catch and handle any exceptions it might throw so that the finally block finishes.
                // Currently it's possible for the socket to fail during reading and sending to the backplane, while
                // leaving the host without performing its cleanup work.
                await host.ProcessConnectionClosedAsync();
            }
            catch (OperationCanceledException)
            {
                this.logger.LogInformation($"Socket {host.SocketId}: Operation Cancelled");
            }
            catch (Exception ex)
            {
                this.logger.LogError("There was a problem while accepting the connection.", ex);
            }
            finally
            {
                broadcastTokenSource.Cancel();

                this.logger.LogInformation($"Socket {host.SocketId}: Ended processing loop in state {socket.State}");

                // Don't leave the socket in any potentially connected state.
                if (socket.State != WebSocketState.Closed)
                {
                    socket.Abort();
                }

                // By this point the socket is closed or aborted, the ConnectedClient object is useless.
                if (this.manifest.Hosts.TryRemove(host.SocketId, out _))
                {
                    socket.Dispose();
                }

                // Signal to the middleware pipeline that this task has completed.
                host.TaskCompletion.SetResult(true);
            }
        }
    }
}