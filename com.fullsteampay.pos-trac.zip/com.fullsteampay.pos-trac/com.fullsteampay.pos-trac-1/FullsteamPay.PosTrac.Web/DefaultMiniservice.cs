﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using FullsteamPay.PosTrac.Domain.Contracts;

    /// <summary>
    /// Represents information about a single miniservice instance.
    /// </summary>
    public class DefaultMiniservice : IMiniservice
    {
        /// <inheritdoc />
        public Guid Id { get; } = Guid.NewGuid();
    }
}