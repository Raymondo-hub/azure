﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using System.Net.WebSockets;
    using System.Text.Json;
    using System.Threading;
    using System.Threading.Channels;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Represents a basic implementation of a web socket host that can be extended to customize behavior based on the
    /// type of the client.
    /// </summary>
    public abstract class BaseWebSocketHost : IWebSocketHost
    {
        /// <summary>
        /// The default JSON serialization options.
        /// </summary>
        private readonly JsonSerializerOptions defaultOptions = IngenicoJsonSerializerOptions.GetDefaultOptions();

        /// <summary>
        /// The backing store for the identifier of the client with which the socket is communicating, if one is available.
        /// </summary>
        private string? socketClientId;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseWebSocketHost" /> class.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <param name="logger">The logger for this component.</param>
        protected BaseWebSocketHost(WebSocket socket, string socketClientId, ILogger logger)
        {
            this.Socket = socket ?? throw new ArgumentNullException(nameof(socket));
            this.Logger = logger ?? throw new ArgumentNullException(nameof(logger));

            this.SocketClientId = socketClientId;
            this.SocketId = Guid.NewGuid();
            this.SocketQueue = Channel.CreateUnbounded<byte[]>(
                new UnboundedChannelOptions
                {
                    SingleReader = true,
                    SingleWriter = false
                });

            // See https://devblogs.microsoft.com/premier-developer/the-danger-of-taskcompletionsourcet-class/ for some
            // information about this.
            this.TaskCompletion = new TaskCompletionSource<object>(TaskCreationOptions.RunContinuationsAsynchronously);
        }

        /// <inheritdoc />
        public CancellationTokenSource BroadcastLoopTokenSource { get; set; } = new();

        /// <inheritdoc />
        public WebSocket Socket { get; }

        /// <inheritdoc />
        public virtual string? SocketClientId
        {
            get => this.socketClientId;
            protected set => this.socketClientId = value is not null ? value.ToNormalizedIdentifier() : null;
        }

        /// <inheritdoc />
        public Guid SocketId { get; }

        /// <inheritdoc />
        public TaskCompletionSource<object> TaskCompletion { get; }

        /// <summary>
        /// Gets the JSON serializer options to use when sending JSON to the client.
        /// </summary>
        protected virtual JsonSerializerOptions ClientSerializerOptions => this.defaultOptions;

        /// <summary>
        /// Gets the logger for this component.
        /// </summary>
        /// <value>The logger for this component.</value>
        protected ILogger Logger { get; }

        /// <summary>
        /// Gets the channel that represents reading and writing to the socket.
        /// </summary>
        /// <value>The channel that represents reading and writing to the socket.</value>
        protected Channel<byte[]> SocketQueue { get; }

        /// <inheritdoc />
        public async Task BroadcastLoopAsync()
        {
            var cancellationToken = this.BroadcastLoopTokenSource.Token;

            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    while (await this.SocketQueue.Reader.WaitToReadAsync(cancellationToken))
                    {
                        this.Logger.LogInformation($"Socket {this.SocketId}: Sending from queue.");

                        var message = await this.SocketQueue.Reader.ReadAsync();
                        var msgbuf = new ArraySegment<byte>(message);

                        await this.Socket.SendAsync(msgbuf, WebSocketMessageType.Text, endOfMessage: true, CancellationToken.None);
                    }
                }
                catch (OperationCanceledException)
                {
                    this.Logger.LogInformation("BroadcastLoopAsync: Operation Cancelled");
                }
                catch (Exception ex)
                {
                    this.Logger.LogError("BroadcastLoopAsync: Exception", ex);
                }
            }
        }

        /// <inheritdoc />
        public virtual Task ProcessConnectionClosedAsync() => Task.CompletedTask;

        /// <inheritdoc />
        public virtual Task ProcessConnectionOpenedAsync() => Task.CompletedTask;

        /// <inheritdoc />
        public abstract Task ProcessSocketMessageAsync(ReadOnlyMemory<byte> buffer);

        /// <inheritdoc />
        public virtual Task SetupAsync() => Task.CompletedTask;

        /// <inheritdoc />
        public Task WriteMessageToSocketAsync<TMessage>(TMessage message)
        {
            var replyBytes = JsonSerializer.SerializeToUtf8Bytes(message, this.ClientSerializerOptions);

            return this.SocketQueue.Writer.WriteAsync(replyBytes).AsTask();
        }

        /// <summary>
        /// Receives a raw message from the client and converts it into a managed message type.
        /// </summary>
        /// <typeparam name="TMessage">The type of the message sent from the client.</typeparam>
        /// <param name="buffer">The message buffer received by the server from the client.</param>
        /// <returns>A <see cref="Task{TMessage}" /> representing the asynchronous operation.</returns>
        protected Task<TMessage> ReceiveClientMessageAsync<TMessage>(ReadOnlyMemory<byte> buffer)
        {
            var message = JsonSerializer.Deserialize<TMessage>(buffer.Span, this.ClientSerializerOptions);

            // If the message from the client could not deserialize, it is not recognized as the correct request type
            // for this type of client and state. We'll need some kind of handling process for this case here.
            if (message is null)
            {
                // TODO: If we want to continue to throw here, we'll probably need a custom type of exception to indicate the problem.
                throw new InvalidOperationException();
            }

            return Task.FromResult(message);
        }
    }
}