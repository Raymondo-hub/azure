﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using System.Net.WebSockets;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using Microsoft.Extensions.DependencyInjection;

    /// <summary>
    /// Represents the default factory that builds hosts for communicating with clients over web sockets.
    /// </summary>
    /// <typeparam name="THost">The type of the host created by the factory.</typeparam>
    /// <remarks>
    /// <typeparamref name="THost" /> must be a concrete type or this factory will throw at runtime. Unfortunately I
    /// couldn't find a good way to specify that with generic constraints.
    /// </remarks>
    public sealed class DefaultWebSocketHostFactory<THost> : IWebSocketHostFactory
        where THost : IWebSocketHost
    {
        /// <summary>
        /// The container used to resolve instances of a service.
        /// </summary>
        private readonly IServiceProvider container;

        /// <summary>
        /// The encapsulated factory that generates the web socket host instances.
        /// </summary>
        private ObjectFactory? factory;

        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultWebSocketHostFactory{THost}" /> class.
        /// </summary>
        /// <param name="container">The container used to resolve instances of a service.</param>
        public DefaultWebSocketHostFactory(IServiceProvider container)
        {
            this.container = container ?? throw new ArgumentNullException(nameof(container));
        }

        /// <summary>
        /// Gets the factory used to create web socket host instances.
        /// </summary>
        /// <remarks>
        /// This is done this way mainly to keep the creation of the factory out of the constructor, and to not create
        /// it until the first time it is accessed.
        /// </remarks>
        private ObjectFactory Factory =>
            this.factory ??= ActivatorUtilities.CreateFactory(typeof(THost), new[] { typeof(WebSocket), typeof(string) });

        /// <inheritdoc />
        public IWebSocketHost CreateHost(WebSocket socket, string socketClientId)
        {
            return (THost)this.Factory(this.container, new object[] { socket, socketClientId });
        }
    }
}