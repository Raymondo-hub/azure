﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.WebSockets;
    using System.Threading;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// The default implementation of the connection manifest that tracks web socket connections for the application.
    /// </summary>
    public sealed class DefaultConnectionManifest : IConnectionManifest
    {
        /// <summary>
        /// The timeout to close an open web socket.
        /// </summary>
        private static readonly TimeSpan SocketCloseTimeout = TimeSpan.FromMilliseconds(2500);

        /// <summary>
        /// The callback delegate registered with a <see cref="CancellationToken" /> for the application stopping event
        /// of the host.
        /// </summary>
        private readonly CancellationTokenRegistration applicationShutdownHandlerRegistration;

        /// <summary>
        /// The logger for this component.
        /// </summary>
        private readonly ILogger<DefaultConnectionManifest> logger;

        /// <summary>
        /// The backing store intended for a thread-safe implementation of the <see cref="IsServerRunning" /> property.
        /// </summary>
        private int isServerRunningThreadSafe = 1;

        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultConnectionManifest" /> class.
        /// </summary>
        /// <param name="hostLifetime">Allows consumers to be notified of application lifetime events.</param>
        /// <param name="logger">The logger for this component.</param>
        public DefaultConnectionManifest(IHostApplicationLifetime hostLifetime, ILogger<DefaultConnectionManifest> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));

            // Gracefully close all websockets during shutdown (only register on first instantiation). Note that this
            // class is written with the intention of being delivered as a singleton from a DI framework.
            if (this.applicationShutdownHandlerRegistration.Token.Equals(CancellationToken.None))
            {
                this.applicationShutdownHandlerRegistration = hostLifetime.ApplicationStopping.Register(this.ShutdownHandler);
            }
        }

        /// <inheritdoc />
        public ConcurrentDictionary<Guid, IWebSocketHost> Hosts { get; } = new();

        /// <inheritdoc />
        public bool IsServerRunning
        {
            get => Interlocked.CompareExchange(ref this.isServerRunningThreadSafe, 1, 1) == 1;

            private set
            {
                if (value)
                {
                    Interlocked.CompareExchange(ref this.isServerRunningThreadSafe, 1, 0);
                }
                else
                {
                    Interlocked.CompareExchange(ref this.isServerRunningThreadSafe, 0, 1);
                }
            }
        }

        /// <inheritdoc />
        public CancellationTokenSource SocketLoopTokenSource { get; } = new();

        /// <summary>
        /// Closes all connections currently being tracked and disposes them.
        /// </summary>
        /// <returns>A <see cref="Task" /> representing the result of the asynchronous operation.</returns>
        private async Task CloseAllSocketsAsync()
        {
            // We can't dispose the sockets until the processing loops are terminated, but terminating the loops will
            // abort the sockets, preventing graceful closing.
            var disposeQueue = new List<WebSocket>(this.Hosts.Count);

            while (!this.Hosts.IsEmpty)
            {
                var client = this.Hosts.ElementAt(0).Value;

                this.logger.LogInformation($"Closing Socket {client.SocketId}: ending outbound loop.");

                client.BroadcastLoopTokenSource.Cancel();

                if (client.Socket.State != WebSocketState.Open)
                {
                    this.logger.LogInformation($"Closing Socket {client.SocketId}: socket not open, state = {client.Socket.State}.");
                }
                else
                {
                    var timeout = new CancellationTokenSource(SocketCloseTimeout);

                    try
                    {
                        this.logger.LogInformation($"Closing Socket {client.SocketId}: starting close handshake.");
                        await client.Socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", timeout.Token);
                    }
                    catch (OperationCanceledException ex)
                    {
                        this.logger.LogError(ex, $"Closing Socket {client.SocketId}: socket close timed out.");
                    }
                }

                if (this.Hosts.TryRemove(client.SocketId, out _))
                {
                    // Only safe to Dispose once, so only add it if this loop can't process it again.
                    disposeQueue.Add(client.Socket);
                }

                this.logger.LogInformation($"Closing Socket {client.SocketId}: done");
            }

            // Now that they're all closed, terminate the blocking ReceiveAsync calls in the SocketProcessingLoop threads.
            this.SocketLoopTokenSource.Cancel();

            foreach (var socket in disposeQueue)
            {
                socket.Dispose();
            }
        }

        /// <summary>
        /// An event handler that handles the application shutdown event.
        /// </summary>
        /// <remarks>Event handlers are pretty much the only place it's ok to return void with an async method.</remarks>
        private async void ShutdownHandler()
        {
            this.IsServerRunning = false;

            await this.CloseAllSocketsAsync();
        }
    }
}