﻿namespace FullsteamPay.PosTrac.Web
{
    using System;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Defines extension methods for the <see cref="TerminalRegistrationOptions" /> class.
    /// </summary>
    public static class TerminalRegistrationOptionsExtensions
    {
        /// <summary>
        /// Takes the terminal registration options and the terminal identifer to generate a URI to the broker endpoint
        /// to which a terminal should connect.
        /// </summary>
        /// <param name="options">The configuration options for terminal registration.</param>
        /// <param name="terminalId">The identifier of the terminal.</param>
        /// <returns>The URI to which the terminal should connect.</returns>
        public static Uri ToBrokerEndpointUri(this TerminalRegistrationOptions options, string? terminalId)
        {
            if (string.IsNullOrWhiteSpace(options.BrokerEndpointHost))
            {
                throw new ArgumentException(Strings.BrokerEndpointHostIsEmpty, nameof(options));
            }

            // Although its extremely like that whitespace in the path is a configuration mistake, whitespace is
            // significant in URIs once you get past the host segment, and should be preserved. Terminal ID is the same
            // way. This decision only goes with general rules about URIs and can be changed if necessary.
            var builder = new UriBuilder(options.BrokerEndpointUseTls ? "wss" : "ws", options.BrokerEndpointHost, options.BrokerEndpointPort, options.BrokerEndpointPath);

            if (!string.IsNullOrEmpty(terminalId))
            {
                builder.Path = builder.Path.EndsWith('/')
                    ? builder.Path + terminalId
                    : builder.Path + "/" + terminalId;
            }

            return builder.Uri;
        }
    }
}