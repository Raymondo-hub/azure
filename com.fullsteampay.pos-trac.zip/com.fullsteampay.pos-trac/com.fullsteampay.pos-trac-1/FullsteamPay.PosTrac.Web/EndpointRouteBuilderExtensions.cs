﻿namespace FullsteamPay.PosTrac.Web
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Routing;

    /// <summary>
    /// Defines extension methods for the <see cref="IEndpointRouteBuilder" /> class.
    /// </summary>
    public static class EndpointRouteBuilderExtensions
    {
        /// <summary>
        /// Adds a <see cref="RouteEndpoint" /> to the <paramref name="endpoints" /> that uses routing to match requests
        /// for the specified pattern and using the <see cref="WebSocketHostMiddleware" /> middleware.
        /// </summary>
        /// <param name="endpoints">The <see cref="IEndpointRouteBuilder" /> to which to add the route.</param>
        /// <param name="pattern">The route pattern to match.</param>
        /// <returns>A <see cref="IEndpointConventionBuilder" /> that can be used to further customize the endpoint.</returns>
        public static IEndpointConventionBuilder MapWebSocketHostWithRouting(this IEndpointRouteBuilder endpoints, string pattern)
        {
            var pipeline = endpoints.CreateApplicationBuilder()
                .UseMiddleware<WebSocketHostMiddleware>()
                .Build();

            return endpoints.Map(pattern, pipeline).WithDisplayName("Web Socket Broker");
        }
    }
}