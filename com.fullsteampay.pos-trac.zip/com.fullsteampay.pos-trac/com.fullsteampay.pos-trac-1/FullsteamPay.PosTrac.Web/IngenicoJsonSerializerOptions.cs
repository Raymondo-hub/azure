﻿namespace FullsteamPay.PosTrac.Web
{
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using FullsteamPay.PosTrac.Framework;

    /// <summary>
    /// Represents the JSON serializer options for working with messages sent to Ingenico hosts.
    /// </summary>
    public static class IngenicoJsonSerializerOptions
    {
        /// <summary>
        /// Gets the default JSON serializer options for working with messages sent to Ingenico hosts.
        /// </summary>
        /// <returns>A default set of JSON serializer options for Ingenico hosts.</returns>
        public static JsonSerializerOptions GetDefaultOptions()
            => new()
            {
                Converters = { new JsonStringEnumConverter(new JsonSnakeCaseNamingPolicy()) },
                PropertyNamingPolicy = new JsonSnakeCaseNamingPolicy(),
                WriteIndented = true
            };
    }
}