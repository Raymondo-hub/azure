﻿namespace FullsteamPay.PosTrac.Persistence.Services
{
    using System;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using Google.Protobuf.WellKnownTypes;
    using Grpc.Core;
    using Microsoft.Azure.Cosmos;
    using Microsoft.Azure.Cosmos.Linq;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// The gRPC service that performs data actions for terminals.
    /// </summary>
    public class TerminalDataService : TerminalData.TerminalDataBase
    {
        /// <summary>
        /// The Azure Cosmos DB container for terminal documents.
        /// </summary>
        private readonly Container container;

        /// <summary>
        /// The generator for creating random alphanumeric keys.
        /// </summary>
        private readonly IKeyGenerator generator;

        /// <summary>
        /// The logger for this component.
        /// </summary>
        private readonly ILogger<TerminalDataService> logger;

        /// <summary>
        /// The configuration options for activation code generation.
        /// </summary>
        private readonly ActivationCodeGenerationOptions options;

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalDataService" /> class.
        /// </summary>
        /// <param name="cosmos">The Azure Cosmos DB SQL client for data access.</param>
        /// <param name="generator">The generator for creating random alphanumeric keys.</param>
        /// <param name="options">The configuration options for activation code generation.</param>
        /// <param name="logger">The logger for this component.</param>
        public TerminalDataService(CosmosClient cosmos, IKeyGenerator generator, IOptions<ActivationCodeGenerationOptions> options, ILogger<TerminalDataService> logger)
        {
            if (cosmos is null)
            {
                throw new ArgumentNullException(nameof(cosmos));
            }

            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            this.generator = generator ?? throw new ArgumentNullException(nameof(generator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.container = cosmos.GetContainer(Constants.CosmosDatabaseName, Constants.CosmosTerminalContainerName);
            this.options = options.Value;
        }

        /// <inheritdoc />
        public override async Task<ActivateReply> ActivateByActivationCode(ActivateActivationCodeRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to activate terminal for code {request.ActivationCode}.");

            var code = request.ActivationCode.ToUpperInvariant();

            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => p.ActivationCodes.Any(a => a.Code == code))
                .ToFeedIterator();

            return await this.ActivateInternal(iterator);
        }

        /// <inheritdoc />
        public override async Task<ActivateReply> ActivateBySerialNumber(ActivateSerialNumberRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to activate terminal for serial number {request.TerminalSerialNumber}.");

            var vendor = (Domain.TerminalVendor)request.TerminalVendor;

            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => p.SerialNumber == request.TerminalSerialNumber && p.Vendor == vendor)
                .ToFeedIterator();

            return await this.ActivateInternal(iterator);
        }

        /// <inheritdoc />
        public override async Task<ActivateReply> ActivateByTerminalId(ActivateTerminalIdRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to activate terminal for ID {request.TerminalId}.");

            var id = request.TerminalId.ToNormalizedIdentifier();

            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => p.TerminalId == id)
                .ToFeedIterator();

            return await this.ActivateInternal(iterator);
        }

        /// <inheritdoc />
        public override async Task<ConnectReply> Connect(ConnectRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to connect terminal {request.TerminalId} to broker {request.BrokerId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);

            if (terminal is null)
            {
                return new()
                {
                    Status = ConnectStatus.NotFound
                };
            }

            terminal.ConnectedDate = DateTimeOffset.UtcNow;
            terminal.ConnectedToBrokerId = new Guid(request.BrokerId);
            terminal.IsConnected = true;

            var response = await this.container.ReplaceItemAsync(terminal, terminal.Id, partitionKey);

            this.logger.LogInformation($"Terminal {response.Resource.TerminalId} successfully connected to broker {response.Resource.ConnectedToBrokerId} | RU cost: {response.RequestCharge}");

            return new()
            {
                Status = response.StatusCode == HttpStatusCode.OK ? ConnectStatus.Ok : ConnectStatus.Error
            };
        }

        /// <inheritdoc />
        public override async Task<DeactivateReply> Deactivate(DeactivateRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to deactivate terminal with ID {request.TerminalId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);

            if (terminal is null)
            {
                return new()
                {
                    Status = DeactivateStatus.NotFound
                };
            }

            terminal.DeactivatedDate = DateTimeOffset.UtcNow;
            terminal.IsActivated = false;

            var response = await this.container.ReplaceItemAsync(terminal, terminal.Id, partitionKey);

            this.logger.LogInformation($"Terminal {response.Resource.TerminalId} successfully deactivated | RU cost: {response.RequestCharge}");

            return new()
            {
                Status = DeactivateStatus.Ok
            };
        }

        /// <inheritdoc />
        public override async Task<DisconnectReply> Disconnect(DisconnectRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to disconnect terminal {request.TerminalId} from broker {request.BrokerId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);
            var brokerId = new Guid(request.BrokerId);

            // TODO: Consider adding a check to make sure the ConnectedToBrokerId matches the given brokerId, to ensure that a terminal is not indicated disconnected when it shouldn't be.
            if (terminal is null)
            {
                return new()
                {
                    Status = DisconnectStatus.NotFound
                };
            }

            // TODO: Consider what to do if the broker IDs do not match. Currently the connect status will not be
            // changed, as this situation seems most likely to occur when a disconnect call comes in after a connect
            // call from a different broker. In that case we would want the last connect call to win over the disconnect
            // call. However this might be worth some additional consideration.
            if (terminal.ConnectedToBrokerId != brokerId)
            {
                return new()
                {
                    Status = DisconnectStatus.Ok
                };
            }

            terminal.DisconnectedDate = DateTimeOffset.UtcNow;
            terminal.IsConnected = false;

            var response = await this.container.ReplaceItemAsync(terminal, terminal.Id, partitionKey);

            this.logger.LogInformation($"Terminal {response.Resource.TerminalId} successfully disconnected from broker {response.Resource.ConnectedToBrokerId} | RU cost: {response.RequestCharge}");

            return new()
            {
                Status = response.StatusCode == HttpStatusCode.OK ? DisconnectStatus.Ok : DisconnectStatus.Error
            };
        }

        /// <inheritdoc />
        public override async Task<TerminalReply> GetTerminal(TerminalRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to get connection information for terminal {request.TerminalId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);

            return terminal is null
                ? new()
                {
                    Status = FindStatus.NotFound
                }
                : new()
                {
                    ActivatedDate = terminal.ActivatedDate.HasValue ? Timestamp.FromDateTimeOffset(terminal.ActivatedDate.Value) : null,
                    ConnectedDate = terminal.ActivatedDate.HasValue ? Timestamp.FromDateTimeOffset(terminal.ActivatedDate.Value) : null,
                    ConnectedToBrokerId = terminal.ConnectedToBrokerId?.ToString(),
                    CreatedDate = Timestamp.FromDateTimeOffset(terminal.CreatedDate),
                    DeactivatedDate = terminal.ActivatedDate.HasValue ? Timestamp.FromDateTimeOffset(terminal.ActivatedDate.Value) : null,
                    DisconnectedDate = terminal.ActivatedDate.HasValue ? Timestamp.FromDateTimeOffset(terminal.ActivatedDate.Value) : null,
                    IsActivated = terminal.IsActivated,
                    IsConnected = terminal.IsConnected,
                    SerialNumber = terminal.SerialNumber,
                    Status = FindStatus.Ok,
                    Vendor = (Protos.TerminalVendor)terminal.Vendor
                };
        }

        /// <inheritdoc />
        public override async Task<TerminalConnectionReply> GetTerminalConnection(TerminalRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to get connection information for terminal {request.TerminalId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);

            return terminal is null
                ? new()
                {
                    Status = FindStatus.NotFound
                }
                : new()
                {
                    IsActivated = terminal.IsActivated,
                    IsConnected = terminal.IsConnected,
                    Status = FindStatus.Ok
                };
        }

        /// <inheritdoc />
        public override async Task<TerminalIdReply> GetTerminalId(TerminalIdRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to get terminal ID for serial number {request.TerminalSerialNumber} and vendor {request.TerminalVendor}.");

            var vendor = (Domain.TerminalVendor)request.TerminalVendor;

            // Cosmos returns query results using paging, so there is some hoops to jump through to get them into a list asynchronously.
            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => p.SerialNumber == request.TerminalSerialNumber && p.Vendor == vendor)
                .ToFeedIterator();

            var queryResults = await iterator.ToAsyncEnumerable(this.logger).ToListAsync();
            var terminal = queryResults.SingleOrDefault();

            return terminal is null
                ? new()
                {
                    Status = FindStatus.NotFound
                }
                : new()
                {
                    Status = FindStatus.Ok,
                    TerminalId = terminal.TerminalId
                };
        }

        /// <inheritdoc />
        public override async Task<UnactivatedTerminalsReply> GetUnactivatedTerminals(UnactivatedTerminalsRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to get terminal IDs for unactivated terminals for broker with ID {request.BrokerId}.");

            var brokerId = new Guid(request.BrokerId);

            // Cosmos returns query results using paging, so there is some hoops to jump through to get them into a list asynchronously.
            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => !p.IsActivated && p.IsConnected && p.ConnectedToBrokerId == brokerId)
                .Select(s => s.TerminalId)
                .ToFeedIterator();

            var queryResults = await iterator.ToAsyncEnumerable(this.logger).ToListAsync();
            var reply = new UnactivatedTerminalsReply();

            reply.TerminalIds.AddRange(queryResults);

            return reply;
        }

        /// <inheritdoc />
        public override async Task<RegisterReply> Register(RegisterRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to register terminal {request.TerminalSerialNumber}");

            var vendor = (Domain.TerminalVendor)request.TerminalVendor;

            // Cosmos returns query results using paging, so there is some hoops to jump through to get them into a list asynchronously.
            using var iterator = this.container.GetItemLinqQueryable<Terminal>()
                .Where(p => p.SerialNumber == request.TerminalSerialNumber && p.Vendor == vendor)
                .ToFeedIterator();

            var queryResults = await iterator.ToAsyncEnumerable(this.logger).ToListAsync();
            var terminal = queryResults.SingleOrDefault();

            // If the terminal was not found, we have never seen it before and it needs to be added. Otherwise just
            // return the existing terminal ID.
            if (terminal is not null)
            {
                this.logger.LogInformation($"Found terminal for TSN '{request.TerminalSerialNumber}'.");

                return new RegisterReply
                {
                    TerminalId = terminal.TerminalId
                };
            }

            var entity = new Terminal
            {
                CreatedDate = DateTimeOffset.UtcNow,
                SerialNumber = request.TerminalSerialNumber,
                TerminalId = Guid.NewGuid().ToNormalizedIdentifier(),
                Vendor = (Domain.TerminalVendor)request.TerminalVendor
            };

            entity.SetDiscriminatedId(entity.TerminalId);

            // The TerminalId here has already been normalized so there is no need to normalize again when creating the
            // partition key.
            var response = await this.container.CreateItemAsync(entity, new PartitionKey(entity.TerminalId));

            this.logger.LogInformation($"Created item in database with TerminalId '{entity.TerminalId}' and TSN '{entity.SerialNumber}' | RU cost: {response.RequestCharge}");

            return new RegisterReply
            {
                TerminalId = entity.TerminalId
            };
        }

        /// <inheritdoc />
        public override async Task<RotateCodeReply> RotateCode(RotateCodeRequest request, ServerCallContext context)
        {
            this.logger.LogInformation($"Processing request to rotate activation code for terminal ID {request.TerminalId}.");

            var partitionKey = request.TerminalId.ToNormalizedPartitionKey();
            var terminal = await this.container.FindAsync<Terminal>(CosmosDbExtensions.FormatDiscriminatedId<Terminal>(request.TerminalId), partitionKey);

            // If the terminal was not found, it presents a strange situation where we have a connection on the broker
            // for a terminal that has never registered. It should not attempt to do anything and at least log an
            // appropriate message.
            if (terminal is null)
            {
                this.logger.LogWarning($"A host with ID {request.TerminalId} is attempting to rotate a code, but we have no record of this terminal on file.");

                return new() { Status = RotateCodeStatus.NotFound };
            }

            // If the terminal has been activated, it should not attempt to generate an activation code.
            if (terminal.IsActivated)
            {
                return new() { Status = RotateCodeStatus.AlreadyActivated };
            }

            if (terminal.ActivationCodes.Count >= this.options.MaximumConcurrentCodes)
            {
                this.logger.LogInformation($"Terminal {terminal.TerminalId} has too many current activation codes; removing the oldest one.");

                var currentCodes = terminal.ActivationCodes.OrderBy(k => k.CreatedDate).ToList();

                currentCodes.RemoveRange(0, terminal.ActivationCodes.Count - (this.options.MaximumConcurrentCodes - 1));

                terminal.ActivationCodes = currentCodes;
            }

            var code = new ActivationCode
            {
                Code = this.generator.GetRandomKeyFromReducedCharSet(this.options.CodeGenerateLength),
                CreatedDate = DateTimeOffset.UtcNow
            };

            if (!string.IsNullOrWhiteSpace(this.options.CodePrefix))
            {
                code.Code = this.options.CodePrefix.Trim() + code.Code;
            }

            terminal.ActivationCodes.Add(code);

            var response = await this.container.ReplaceItemAsync(terminal, terminal.Id, partitionKey);

            this.logger.LogInformation($"Terminal {response.Resource.TerminalId} successfully rotated activation code | RU cost: {response.RequestCharge}");

            return new()
            {
                ActivationCode = code.Code,
                Status = RotateCodeStatus.Ok
            };
        }

        /// <summary>
        /// Performs the work of enumerating the terminal selection query and activating it.
        /// </summary>
        /// <param name="iterator">The Cosmos feed iterator representing a query to execute.</param>
        /// <returns>
        /// A <see cref="Task" /> representing the asynchronous operation and containing the reply to the client about
        /// activating the terminal.
        /// </returns>
        private async Task<ActivateReply> ActivateInternal(FeedIterator<Terminal> iterator)
        {
            var queryResults = await iterator.ToAsyncEnumerable(this.logger).ToListAsync();
            var terminal = queryResults.SingleOrDefault();

            if (terminal is null)
            {
                this.logger.LogInformation("Terminal not found.");

                return new()
                {
                    Status = ActivateStatus.NotFound
                };
            }

            terminal.ActivatedDate = DateTimeOffset.UtcNow;
            terminal.ActivationCodes.Clear();
            terminal.IsActivated = true;

            // The TerminalId here has already been normalized so there is no need to normalize again when creating the
            // partition key.
            var response = await this.container.ReplaceItemAsync(terminal, terminal.Id, new PartitionKey(terminal.TerminalId));

            this.logger.LogInformation($"Terminal {response.Resource.TerminalId} successfully activated | RU cost: {response.RequestCharge}");

            return new()
            {
                Status = ActivateStatus.Ok,
                TerminalId = terminal.TerminalId
            };
        }
    }
}