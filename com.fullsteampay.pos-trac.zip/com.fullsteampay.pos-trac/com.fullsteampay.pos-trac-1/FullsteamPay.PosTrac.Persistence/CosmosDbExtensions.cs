﻿namespace FullsteamPay.PosTrac.Persistence
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Net;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using Microsoft.Azure.Cosmos;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Defines extension methods for Cosmos DB objects.
    /// </summary>
    public static class CosmosDbExtensions
    {
        /// <summary>
        /// Finds an entity with the given identifier in the specified partition. If no entity is found, the default
        /// entity value is returned, usually <c>null</c>.
        /// </summary>
        /// <typeparam name="TEntity">The type of the entity to find.</typeparam>
        /// <param name="container">The Cosmos DB container this method extends.</param>
        /// <param name="identifier">The identifier of the entity.</param>
        /// <param name="partitionKey">The partition key for the entity.</param>
        /// <returns>
        /// A <see cref="Task" /> representing the asynchronous operation containing the found entity, or <c>null</c>.
        /// </returns>
        public static async Task<TEntity?> FindAsync<TEntity>(this Container container, string identifier, PartitionKey partitionKey)
        {
            try
            {
                var query = await container.ReadItemAsync<TEntity>(identifier, partitionKey);

                return query.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return default;
            }
        }

        /// <summary>
        /// Formats a discriminated identifier used in Azure Cosmos DB for the indicated value and type.
        /// </summary>
        /// <typeparam name="TEntity">The type of the entity.</typeparam>
        /// <param name="identifier">The identifier to use.</param>
        /// <returns>A discriminated identifier used in Azure Cosmos DB.</returns>
        public static string FormatDiscriminatedId<TEntity>(string identifier)
            where TEntity : ICosmosEntity
            => string.Format(CultureInfo.InvariantCulture, Constants.CosmosEntityDiscriminatedIdFormat, typeof(TEntity).Name, identifier.ToNormalizedIdentifier());

        /// <summary>
        /// Generates a new discriminated identifier used in Azure Cosmos DB for the indicated type.
        /// </summary>
        /// <typeparam name="TEntity">The type of the entity.</typeparam>
        /// <returns>A discriminated identifier used in Azure Cosmos DB.</returns>
        public static string GenerateDiscriminatedId<TEntity>()
            where TEntity : ICosmosEntity
            => FormatDiscriminatedId<TEntity>(Guid.NewGuid().ToNormalizedIdentifier());

        /// <summary>
        /// Sets the <see cref="ICosmosEntity.Id" /> property of the entity using a discriminated identifier formatted
        /// from the given identifier.
        /// </summary>
        /// <typeparam name="TEntity">The type of the entity.</typeparam>
        /// <param name="entity">The entity on which to set the property.</param>
        /// <param name="identifier">The base identifier to format with the discriminator.</param>
        public static void SetDiscriminatedId<TEntity>(this TEntity entity, string identifier)
            where TEntity : ICosmosEntity
            => entity.Id = FormatDiscriminatedId<TEntity>(identifier);

        /// <summary>
        /// Converts a Cosmos DB feed iterator to <see cref="IAsyncEnumerable{T}" />.
        /// </summary>
        /// <typeparam name="TModel">The model being queried.</typeparam>
        /// <param name="setIterator">
        /// Cosmos result iterator that keeps track of continuation token when retrieving results from a query.
        /// </param>
        /// <returns>An <see cref="IAsyncEnumerable{T}" /> for the result set.</returns>
        public static async IAsyncEnumerable<TModel> ToAsyncEnumerable<TModel>(this FeedIterator<TModel> setIterator)
        {
            while (setIterator.HasMoreResults)
            {
                foreach (var item in await setIterator.ReadNextAsync())
                {
                    yield return item;
                }
            }
        }

        /// <summary>
        /// Converts a Cosmos DB feed iterator to <see cref="IAsyncEnumerable{T}" /> and logs the RU cost for each query.
        /// </summary>
        /// <typeparam name="TModel">The model being queried.</typeparam>
        /// <param name="setIterator">
        /// Cosmos result iterator that keeps track of continuation token when retrieving results from a query.
        /// </param>
        /// <param name="logger">The logger for logging RU cost.</param>
        /// <returns>An <see cref="IAsyncEnumerable{T}" /> for the result set.</returns>
        public static async IAsyncEnumerable<TModel> ToAsyncEnumerable<TModel>(this FeedIterator<TModel> setIterator, ILogger logger)
        {
            while (setIterator.HasMoreResults)
            {
                var results = await setIterator.ReadNextAsync();

                logger.LogInformation($"Query RU cost: {results.RequestCharge}");

                foreach (var item in results)
                {
                    yield return item;
                }
            }
        }

        /// <summary>
        /// Creates a Cosmos DB partition key used in queries by normalizing the identifier.
        /// </summary>
        /// <param name="identifier">The identifier to normalize and use as the partition key.</param>
        /// <returns>A <see cref="PartitionKey" /> using the normalized identifier.</returns>
        public static PartitionKey ToNormalizedPartitionKey(this string identifier)
            => new(identifier.ToNormalizedIdentifier());
    }
}