﻿namespace FullsteamPay.PosTrac.Persistence
{
    using System;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Services;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Azure.Cosmos;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Represents the bootstrapper for initializing configuration and services for the data persistence service.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup" /> class.
        /// </summary>
        /// <param name="environment">
        /// Provides information about the web hosting environment in which the application is running.
        /// </param>
        public Startup(IWebHostEnvironment environment)
        {
            this.CurrentEnvironment = environment ?? throw new ArgumentNullException(nameof(environment));
        }

        /// <summary>
        /// Gets an object that provides information about the web hosting environment in which the application is running.
        /// </summary>
        /// <value>
        /// An object that provides information about the web hosting environment in which the application is running.
        /// </value>
        public IWebHostEnvironment CurrentEnvironment { get; }

        /// <summary>
        /// Configure the HTTP request pipeline. This method is called by the runtime.
        /// </summary>
        /// <param name="app">Provides the mechanisms to configure the applications request pipeline.</param>
        public void Configure(IApplicationBuilder app)
        {
            if (this.CurrentEnvironment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGrpcService<TerminalDataService>();
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync(Strings.GrpcUnsupportedRequest);
                });
            });
        }

        /// <summary>
        /// Configure services in the dependency injection container. This method is called by the runtime.
        /// </summary>
        /// <param name="services">The collection of dependency injection service descriptors for the application.</param>
        /// <remarks>For more information on how to configure your application, visit <a href="https://go.microsoft.com/fwlink/?LinkID=398940" />.</remarks>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetry();
            services.AddGrpc();
            services.AddOptions<AzureCosmosOptions>().BindConfiguration(AzureCosmosOptions.SectionName);

            // Just a note that in .NET 5.0, this validates the data annotations on first use, so only when the options
            // are first used as a dependency. In .NET 6.0 there is supposed to be a way to validate eagerly (on
            // application startup) if that behavior is desired.
            services.AddOptions<ActivationCodeGenerationOptions>().BindConfiguration(ActivationCodeGenerationOptions.SectionName).ValidateDataAnnotations();
            services.AddSingleton(this.RegisterCosmosClient);
            services.AddSingleton<IKeyGenerator, KeyGenerator>();
        }

        /// <summary>
        /// A factory method delegate for creating an Azure Cosmos client.
        /// </summary>
        /// <param name="provider">The dependency injection service provider for resolving any needed configuration.</param>
        /// <returns>An Azure Cosmos client.</returns>
        private CosmosClient RegisterCosmosClient(IServiceProvider provider)
        {
            var options = provider.GetService<IOptions<AzureCosmosOptions>>();

            if (options is null)
            {
                throw new InvalidOperationException(Strings.CosmosConfigurationNotRegistered);
            }

            if (string.IsNullOrWhiteSpace(options.Value.AccessKey))
            {
                throw new InvalidOperationException(Strings.CosmosAccessKeyNotConfigured);
            }

            if (string.IsNullOrWhiteSpace(options.Value.AccountEndpoint))
            {
                throw new InvalidOperationException(Strings.CosmosAccountEndpointNotConfigured);
            }

            var cosmosOptions = new CosmosClientOptions
            {
                SerializerOptions = new()
                {
                    PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase
                }
            };

            return new CosmosClient(options.Value.AccountEndpoint, options.Value.AccessKey, cosmosOptions);
        }
    }
}