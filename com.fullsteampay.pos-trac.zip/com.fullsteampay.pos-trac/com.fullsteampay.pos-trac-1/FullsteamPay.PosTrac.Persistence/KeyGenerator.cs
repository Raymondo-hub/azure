﻿namespace FullsteamPay.PosTrac.Persistence
{
    using System.Security.Cryptography;
    using System.Text;
    using FullsteamPay.PosTrac.Domain.Contracts;

    /// <summary>
    /// Represents a generator that creates random alphanumeric keys.
    /// </summary>
    public sealed class KeyGenerator : IKeyGenerator
    {
        /// <summary>
        /// The set of reduced alphanumeric characters to use in a key.
        /// </summary>
        private static readonly char[] ReducedCharacters = "ABCDEFGHJKLMNPRSTUVWXYZ23456789".ToCharArray();

        /// <summary>
        /// The set of standard alphanumeric characters to use in a key.
        /// </summary>
        private static readonly char[] StandardCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();

        /// <inheritdoc />
        public string GetRandomKey(int size) => GetRandomKeyInternal(size, StandardCharacters);

        /// <inheritdoc />
        public string GetRandomKeyFromReducedCharSet(int size) => GetRandomKeyInternal(size, ReducedCharacters);

        /// <summary>
        /// Performs the work of generating the random key for the given size and character set.
        /// </summary>
        /// <param name="size">The size of the key to generate.</param>
        /// <param name="characters">The set from which to use characters in the key.</param>
        /// <returns>A random key generated from the given character set.</returns>
        private static string GetRandomKeyInternal(int size, char[] characters)
        {
            var builder = new StringBuilder(size);

            for (var i = 0; i < size; i++)
            {
                var random = RandomNumberGenerator.GetInt32(characters.Length);

                builder.Append(characters[random]);
            }

            return builder.ToString();
        }
    }
}