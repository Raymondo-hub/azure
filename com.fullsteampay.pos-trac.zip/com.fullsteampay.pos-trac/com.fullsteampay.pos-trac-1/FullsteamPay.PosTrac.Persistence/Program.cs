﻿namespace FullsteamPay.PosTrac.Persistence
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Represents the primary execution unit of this application.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Configures the web host for the application.
        /// </summary>
        /// <param name="args">The collection of command line arguments passed into the runtime.</param>
        /// <returns>An abstraction for building the web host.</returns>
        /// <remarks>For instructions on how to configure Kestrel and gRPC clients on macOS, visit <a href="https://go.microsoft.com/fwlink/?linkid=2099682" />.</remarks>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    // See
                    // https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration/?view=aspnetcore-5.0#default
                    // for the order in which configuration is used. The CreateDefaultBuilder() call automatically sets
                    // up the referenced providers and ordering. If we want to use a custom prefix when binding
                    // configuration environment variables we would use the code `config.AddEnvironmentVariables(prefix:
                    // "MyCustomPrefix_");` inside the `ConfigureAppConfiguration()` method chained before this one. My
                    // understanding is that it will allow you to have all your environment variables prefixed with
                    // "POSTRAC_" and still bind to option properties that don't have the prefix name in them. So
                    // "POSTRAC_AZURECOSMOS__ACCOUNTENDPOINT" would bind to the AccountEndpoint property on the
                    // AzureCosmosOptions object. The double underscore is the sub-property notation in environment
                    // variables, so "AZURECOSMOS__ACCOUNTENDPOINT" corresponds to
                    // AzureCosmos: AccountEndpoint in JSON configuration. The CreateDefaultBuilder() call sets up a lot
                    // of plumbing automatically, such as adding the user secrets configuration source when in
                    // Development mode and other things as I come across them.
                    webBuilder.UseStartup<Startup>();

                    // TODO: Switch to actual logging framework and remove references to Microsoft.Extensions.Logging (if necessary).
                    webBuilder.ConfigureLogging(c => c.AddSimpleConsole(o => o.TimestampFormat = "[MM/dd/yyyy HH:mm:ss] "));
                });

        /// <summary>
        /// The main entry point for the application executed by the runtime.
        /// </summary>
        /// <param name="args">The collection of command line arguments passed into the runtime.</param>
        public static void Main(string[] args) => CreateHostBuilder(args).Build().Run();
    }
}