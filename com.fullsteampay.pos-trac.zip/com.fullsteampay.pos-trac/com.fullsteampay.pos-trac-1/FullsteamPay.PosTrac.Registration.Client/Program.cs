﻿
namespace FullsteamPay.PosTrac.Registration.Client
{
    using System;
    using System.Net.WebSockets;
    using System.Runtime.CompilerServices;
    using System.Threading.Tasks;

    internal class Program
    {
        private static async Task Main(string[] args)
        {
            var running = true;

            while (running)
            {
                Console.Clear();
                await MainThreadUILoop(args);
                Console.WriteLine("\nPress R to re-connect or any other key to exit.");

                var key = Console.ReadKey(intercept: true);

                running = (key.Key == ConsoleKey.R);
            }
        }

        private static async Task MainThreadUILoop(string[] args)
        {
            try
            {
                var port = args.Length > 0 ? args[0] : "8080";

                await WebSocketClient.StartAsync(@$"ws://localhost:{port}/");
                Console.WriteLine("Press ESC to exit. Other keystrokes are sent to the echo server.\n\n");

                var running = true;

                while (running && WebSocketClient.State == WebSocketState.Open)
                {
                    if (Console.KeyAvailable)
                    {
                        var key = Console.ReadKey(intercept: true);

                        if (key.Key == ConsoleKey.Escape)
                        {
                            running = false;
                        }
                        else
                        {
                            WebSocketClient.QueueKeystroke(key.KeyChar.ToString());
                        }
                    }
                }

                await WebSocketClient.StopAsync();
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation canceled");
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        public static void ReportException(Exception ex, [CallerMemberName]string location = "(Caller name not set)")
        {
            Console.WriteLine($"\n{location}:\n  Exception {ex.GetType().Name}: {ex.Message}");
            if (ex.InnerException != null)
                Console.WriteLine($"  Inner Exception {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
        }
    }
}
