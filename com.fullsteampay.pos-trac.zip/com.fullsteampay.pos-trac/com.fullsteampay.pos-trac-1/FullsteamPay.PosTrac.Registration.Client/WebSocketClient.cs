﻿namespace FullsteamPay.PosTrac.Registration.Client
{
    using System;
    using System.Net.WebSockets;
    using System.Text;
    using System.Threading;
    using System.Threading.Channels;
    using System.Threading.Tasks;

    public static class WebSocketClient
    {
        private static CancellationTokenSource keystrokeLoopTokenSource;

        private static Channel<string> keystrokeQueue;

        private static ClientWebSocket socket;

        private static CancellationTokenSource socketLoopTokenSource;

        public static WebSocketState State
        {
            get => socket?.State ?? WebSocketState.None;
        }

        // The TryWrite it guarenteed to succeeed with an unbounded channel.
        public static void QueueKeystroke(string message) => keystrokeQueue.Writer.TryWrite(message);

        public static async Task StartAsync(string wsUri) => await StartAsync(new Uri(wsUri));

        public static async Task StartAsync(Uri wsUri)
        {
            Console.WriteLine($"Connecting to server {wsUri}");

            keystrokeQueue = Channel.CreateUnbounded<string>(
                new UnboundedChannelOptions
                {
                    SingleReader = true,
                    SingleWriter = true
                });

            socketLoopTokenSource = new CancellationTokenSource();
            keystrokeLoopTokenSource = new CancellationTokenSource();

            try
            {
                socket = new ClientWebSocket();

                await socket.ConnectAsync(wsUri, CancellationToken.None);

                _ = Task.Run(() => SocketProcessingLoopAsync().ConfigureAwait(false));
                _ = Task.Run(() => KeystrokeTransmitLoopAsync().ConfigureAwait(false));
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation canceled");
            }
        }

        public static async Task StopAsync()
        {
            Console.WriteLine("\nClosing connection");

            keystrokeLoopTokenSource.Cancel();

            if (socket is null || socket.State != WebSocketState.Open)
            {
                return;
            }

            // Close the socket first, because ReceiveAsync leaves an invalid socket (state = aborted) when the token is cancelled.
            var timeout = new CancellationTokenSource(10000);

            try
            {
                // After this, the socket state which change to CloseSent.
                await socket.CloseOutputAsync(WebSocketCloseStatus.NormalClosure, "Closing", timeout.Token);

                // Now we wait for the server response, which will close the socket.
                while (socket.State != WebSocketState.Closed && !timeout.Token.IsCancellationRequested)
                {
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation canceled");
            }

            // Whether we closed the socket or timed out, we cancel the token causing RecieveAsync to abort the socket.
            socketLoopTokenSource.Cancel();
        }

        private static async Task KeystrokeTransmitLoopAsync()
        {
            var cancellationToken = keystrokeLoopTokenSource.Token;

            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    while (await keystrokeQueue.Reader.WaitToReadAsync(cancellationToken))
                    {
                        var message = await keystrokeQueue.Reader.ReadAsync(cancellationToken);
                        var msgbuf = new ArraySegment<byte>(Encoding.UTF8.GetBytes(message));

                        await socket.SendAsync(msgbuf, WebSocketMessageType.Text, endOfMessage: true, CancellationToken.None);
                    }
                }
                catch (OperationCanceledException)
                {
                    Console.WriteLine("Operation canceled");
                }
                catch (Exception ex)
                {
                    Program.ReportException(ex);
                }
            }
        }

        private static async Task SocketProcessingLoopAsync()
        {
            var cancellationToken = socketLoopTokenSource.Token;

            try
            {
                var buffer = WebSocket.CreateClientBuffer(4096, 4096);

                while (socket.State != WebSocketState.Closed && !cancellationToken.IsCancellationRequested)
                {
                    var receiveResult = await socket.ReceiveAsync(buffer, cancellationToken);

                    // If the token is cancelled while ReceiveAsync is blocking, the socket state changes to aborted and
                    // it can't be used.
                    if (!cancellationToken.IsCancellationRequested)
                    {
                        // The server is notifying us that the connection will close; send acknowledgement.
                        if (socket.State == WebSocketState.CloseReceived && receiveResult.MessageType == WebSocketMessageType.Close)
                        {
                            Console.WriteLine($"\nAcknowledging Close frame received from server");
                            keystrokeLoopTokenSource.Cancel();

                            await socket.CloseOutputAsync(WebSocketCloseStatus.NormalClosure, "Acknowledge Close frame", CancellationToken.None);
                        }

                        // Display text or binary data.
                        if (socket.State == WebSocketState.Open && receiveResult.MessageType != WebSocketMessageType.Close)
                        {
                            var message = Encoding.UTF8.GetString(buffer.Array, 0, receiveResult.Count);

                            if (message.Length > 1)
                            {
                                message = $"\n{message}\n";
                            }

                            Console.Write(message);
                        }
                    }
                }

                Console.WriteLine($"Ending processing loop in state {socket.State}");
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation canceled");
            }
            catch (Exception ex)
            {
                Program.ReportException(ex);
            }
            finally
            {
                keystrokeLoopTokenSource.Cancel();
                socket.Dispose();
                socket = null;
            }
        }
    }
}