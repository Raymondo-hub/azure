﻿namespace FullsteamPay.PosTrac.Broker
{
    using System;
    using System.Net.WebSockets;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Framework;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using FullsteamPay.PosTrac.Web.Redis;
    using Microsoft.Extensions.Logging;
    using StackExchange.Redis;

    /// <summary>
    /// Represents a web socket host for handling communication with an Ingenico terminal in the broker service.
    /// </summary>
    public sealed class IngenicoBrokerWebSocketHost : RedisWebSocketHost
    {
        /// <summary>
        /// The gRPC client for interacting with terminal data persistence.
        /// </summary>
        private readonly TerminalData.TerminalDataClient client;

        /// <summary>
        /// The information for the miniservice in which this component is executing.
        /// </summary>
        private readonly IMiniservice miniservice;

        /// <summary>
        /// Initializes a new instance of the <see cref="IngenicoBrokerWebSocketHost" /> class.
        /// </summary>
        /// <param name="socket">The web socket connection to the client.</param>
        /// <param name="socketClientId">The identifier of the client with which the socket is communicating.</param>
        /// <param name="client">The gRPC client for interacting with terminal data persistence.</param>
        /// <param name="multiplexer">The connection multiplexer for accessing the redis service.</param>
        /// <param name="miniservice">The information for the miniservice in which this component is executing.</param>
        /// <param name="logger">The logger for this component.</param>
        public IngenicoBrokerWebSocketHost(
            WebSocket socket,
            string socketClientId,
            TerminalData.TerminalDataClient client,
            IConnectionMultiplexer multiplexer,
            IMiniservice miniservice,
            ILogger<IngenicoBrokerWebSocketHost> logger)
            : base(socket, socketClientId, multiplexer, logger)
        {
            this.client = client ?? throw new ArgumentNullException(nameof(client));
            this.miniservice = miniservice ?? throw new ArgumentNullException(nameof(miniservice));
        }

        /// <inheritdoc />
        protected override string PublishingChannelNameFormat => Constants.RedisControlSubscriberChannelNameFormat;

        /// <inheritdoc />
        protected override string SubscribingChannelNameFormat => Constants.RedisBrokerSubscriberChannelNameFormat;

        /// <inheritdoc />
        public override async Task ProcessConnectionClosedAsync()
        {
            var request = new DisconnectRequest
            {
                BrokerId = this.miniservice.Id.ToString(),
                TerminalId = this.SocketClientId
            };

            var reply = await this.client.DisconnectAsync(request);

            if (reply.Status == DisconnectStatus.NotFound)
            {
                this.Logger.LogWarning($"A host with socket ID {this.SocketId}  and client ID {this.SocketClientId} attempted to disconnect, but the host was not recognized by the system.");

                // TODO: If we continue to use an exception here, we should probably implement a custom exception.
                throw new InvalidOperationException("An unrecognized host attempted to connect to the broker.");
            }

            this.Logger.LogInformation($"Disconnected terminal {this.SocketClientId} from broker {this.miniservice.Id} with status {reply.Status}");
        }

        /// <inheritdoc />
        public override async Task ProcessConnectionOpenedAsync()
        {
            var request = new ConnectRequest
            {
                BrokerId = this.miniservice.Id.ToString(),
                TerminalId = this.SocketClientId
            };

            var reply = await this.client.ConnectAsync(request);

            if (reply.Status == ConnectStatus.NotFound)
            {
                this.Logger.LogWarning($"A host with socket ID {this.SocketId}  and client ID {this.SocketClientId} attempted to connect, but the host was not recognized by the system.");

                // TODO: If we continue to use an exception here, we should probably implement a custom exception.
                throw new InvalidOperationException("An unrecognized host attempted to connect to the broker.");
            }

            this.Logger.LogInformation($"Connected terminal {this.SocketClientId} to broker {this.miniservice.Id} with status {reply.Status}");
        }

        /// <inheritdoc />
        public override Task ProcessSocketMessageAsync(ReadOnlyMemory<byte> buffer) => this.Subscriber.PublishAsync(this.PublishingChannelName, buffer);

        /// <inheritdoc />
        // Messages received from the subscription are coming from the control service and should be forwarded to the
        // web socket (the terminal).
        protected override Task ProcessSubscriberMessageAsync(ChannelMessage message) => this.SocketQueue.Writer.WriteAsync(message.Message).AsTask();
    }
}