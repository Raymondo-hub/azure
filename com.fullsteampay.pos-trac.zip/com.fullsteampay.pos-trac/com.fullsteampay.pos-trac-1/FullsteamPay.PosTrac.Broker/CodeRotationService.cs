﻿namespace FullsteamPay.PosTrac.Broker
{
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using FullsteamPay.PosTrac.Domain;
    using FullsteamPay.PosTrac.Domain.Contracts;
    using FullsteamPay.PosTrac.Domain.Ingenico;
    using FullsteamPay.PosTrac.Persistence.Protos;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Represents a hosted service that rotates activation codes for connected terminals that are not activated.
    /// </summary>
    public sealed class CodeRotationService : IHostedService, IDisposable
    {
        /// <summary>
        /// The gRPC client for interacting with terminal data persistence.
        /// </summary>
        private readonly TerminalData.TerminalDataClient client;

        /// <summary>
        /// The logger for this component.
        /// </summary>
        private readonly ILogger<CodeRotationService> logger;

        /// <summary>
        /// The manifest of hosts currently active for the whole service.
        /// </summary>
        private readonly IConnectionManifest manifest;

        /// <summary>
        /// The information for the miniservice in which this component is executing.
        /// </summary>
        private readonly IMiniservice miniservice;

        /// <summary>
        /// The configuration options for broker activation code rotation.
        /// </summary>
        private readonly BrokerCodeRotationOptions options;

        /// <summary>
        /// A value indicating whether this instance has already been disposed.
        /// </summary>
        private bool disposedValue;

        /// <summary>
        /// The timer that indicates when codes should be rotated.
        /// </summary>
        private Timer? rotationTimer;

        /// <summary>
        /// Initializes a new instance of the <see cref="CodeRotationService" /> class.
        /// </summary>
        /// <param name="client">The gRPC client for interacting with terminal data persistence.</param>
        /// <param name="manifest">The manifest of hosts currently active for the whole service.</param>
        /// <param name="miniservice">The information for the miniservice in which this component is executing.</param>
        /// <param name="options">The configuration options for broker activation code rotation.</param>
        /// <param name="logger">The logger for this component.</param>
        public CodeRotationService(
            TerminalData.TerminalDataClient client,
            IConnectionManifest manifest,
            IMiniservice miniservice,
            IOptions<BrokerCodeRotationOptions> options,
            ILogger<CodeRotationService> logger)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            this.client = client ?? throw new ArgumentNullException(nameof(client));
            this.manifest = manifest ?? throw new ArgumentNullException(nameof(manifest));
            this.miniservice = miniservice ?? throw new ArgumentNullException(nameof(miniservice));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.options = options.Value;
        }

        /// <inheritdoc />
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            this.Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <inheritdoc />
        public Task StartAsync(CancellationToken cancellationToken)
        {
            this.rotationTimer = new Timer(this.RotateCodes, null, TimeSpan.Zero, this.options.RotationInterval);

            return Task.CompletedTask;
        }

        /// <inheritdoc />
        public Task StopAsync(CancellationToken cancellationToken)
        {
            this.rotationTimer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        /// <summary>
        /// Releases any resources that this instance may contain.
        /// </summary>
        /// <param name="disposing">
        /// <c>true</c> if this instance is being disposed and should release managed resources; otherwise, <c>false</c>.
        /// </param>
        private void Dispose(bool disposing)
        {
            if (!this.disposedValue)
            {
                if (disposing)
                {
                    // Release any managed resources here.
                    this.rotationTimer?.Dispose();
                    this.rotationTimer = null;
                }

                // Release any unmanaged resources here. If any unmanaged resources exist, a finalizer should also be implemented.
                this.disposedValue = true;
            }
        }

        /// <summary>
        /// Rotates the activation code for the given terminal indentifier.
        /// </summary>
        /// <param name="terminalId">The identifier of the terminal.</param>
        /// <returns>A <see cref="Task" /> representing the asynchronous operation.</returns>
        private async Task RotateCodeAsync(string terminalId)
        {
            // TODO: Figure out a better way to handle multiple connections from the same host/terminal.
            var host = this.manifest.Hosts.Where(p => p.Value.SocketClientId == terminalId).Select(s => s.Value).FirstOrDefault();

            // If the host is null, the terminal has been disconnected from this broker without calling Disconnect or is
            // otherwise not being serviced by this broker.
            if (host is null)
            {
            }
            else
            {
                this.logger.LogInformation($"Rotating code for terminal {terminalId}.");

                var response = await this.client.RotateCodeAsync(new() { TerminalId = terminalId });

                // If the response contains no data, the terminal was either not found or it is already registered. In
                // that case, nothing should be done.
                if (response is null || string.IsNullOrEmpty(response.ActivationCode) || response.Status != RotateCodeStatus.Ok)
                {
                    return;
                }

                // TODO: This is strongly coupled with Ingenico, find a way to decouple.
                var message = FormMessage.CreateStandardActivationForm(response.ActivationCode);

                await host.WriteMessageToSocketAsync(message);
            }
        }

        /// <summary>
        /// An action delegate that runs when the timer interval fires that rotates activation codes for connected
        /// terminals that are not currently activated.
        /// </summary>
        /// <param name="state">An optional object represent state that is passed from the timer.</param>
        /// <remarks>
        /// As this delegate is an event handler, this is one of the few acceptable places to have an <c>async</c>
        /// method that returns <c>void</c>.
        /// </remarks>
        private async void RotateCodes(object? state)
        {
            this.logger.LogInformation($"Starting process to rotate terminal activation codes for broker {this.miniservice.Id}.");

            if (this.manifest.Hosts.IsEmpty)
            {
                this.logger.LogInformation("There are no terminals currently connected to this broker.");

                return;
            }

            var unactivated = await this.client.GetUnactivatedTerminalsAsync(new UnactivatedTerminalsRequest { BrokerId = this.miniservice.Id.ToString() });

            this.logger.LogInformation($"Found {unactivated.TerminalIds.Count} un-activated terminals to rotate codes.");
            this.logger.LogInformation($"There are {this.manifest.Hosts.Count} total terminals connected to this broker.");

            var tasks = unactivated.TerminalIds.Select(s => this.RotateCodeAsync(s));

            await Task.WhenAll(tasks);
        }
    }
}