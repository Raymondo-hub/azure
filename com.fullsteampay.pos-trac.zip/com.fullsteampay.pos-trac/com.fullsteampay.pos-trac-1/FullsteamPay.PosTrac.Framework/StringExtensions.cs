﻿namespace FullsteamPay.PosTrac.Framework
{
    using System;
    using System.Text;

    /// <summary>
    /// Defines extension methods for the <see cref="string" /> class.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Describes the various states for the last evaluated character in a separated case conversion.
        /// </summary>
        private enum SeparatedCaseState
        {
            /// <summary>
            /// The last evaluated character was the start of a new word already in separated case.
            /// </summary>
            Start,

            /// <summary>
            /// The last evaluated character was a lowercase letter.
            /// </summary>
            Lower,

            /// <summary>
            /// The last evaluated character was an uppercase letter.
            /// </summary>
            Upper,

            /// <summary>
            /// The last evaluated character was the beginning of a new word.
            /// </summary>
            NewWord
        }

        /// <summary>
        /// Converts the given value to a kebab case format. Kebab case describes a naming scheme where "MyNewVariable"
        /// or "My new Variable" becomes "my-new-variable".
        /// </summary>
        /// <param name="value">The string value to convert.</param>
        /// <returns>The string in kebab case format.</returns>
        public static string ToKebabCase(this string value) => ToSeparatedCase(value, '-');

        /// <summary>
        /// Converts the first character of the given value to lower case using the casing rules of the invariant culture.
        /// </summary>
        /// <param name="value">The value to convert.</param>
        /// <returns>The original first with the first character in lower case.</returns>
        public static string ToLowerInvariantFirstCharacter(this string value) => string.IsNullOrEmpty(value) ? value : char.ToLowerInvariant(value[0]) + value[1..];

        /// <summary>
        /// Normalizes the given value to an identifier by ensuring that all alpha characters are lowercase and any
        /// whitespace is removed.
        /// </summary>
        /// <param name="value">The value to be normalized as an identifier.</param>
        /// <returns>A normalized identifier.</returns>
        /// <remarks>The rather odd way this is implemented comes from <a href="https://stackoverflow.com/a/30732794">here</a>.</remarks>
        public static string ToNormalizedIdentifier(this string value)
            => value is null
                ? string.Empty
                : string.Join(string.Empty, value.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries)).ToLowerInvariant();

        /// <summary>
        /// Converts the given value to a snake case format. Snake case describes a naming scheme where "MyNewVariable"
        /// or "My new Variable" becomes "my_new_variable".
        /// </summary>
        /// <param name="value">The string value to convert.</param>
        /// <returns>The string in snake case format.</returns>
        public static string ToSnakeCase(this string value) => ToSeparatedCase(value, '_');

        /// <summary>
        /// Converts a string value to a separated case format using <paramref name="separator" /> as the word separator.
        /// </summary>
        /// <param name="value">The string value to convert.</param>
        /// <param name="separator">The character to separate individual words.</param>
        /// <returns>The string value in separated case format.</returns>
        private static string ToSeparatedCase(string value, char separator)
        {
            if (string.IsNullOrEmpty(value))
            {
                return value;
            }

            var builder = new StringBuilder();
            var state = SeparatedCaseState.Start;
            var valueSpan = value.AsSpan();

            for (var i = 0; i < valueSpan.Length; i++)
            {
                if (valueSpan[i] == ' ')
                {
                    if (state != SeparatedCaseState.Start)
                    {
                        state = SeparatedCaseState.NewWord;
                    }
                }
                else if (char.IsUpper(valueSpan[i]))
                {
                    switch (state)
                    {
                        case SeparatedCaseState.Upper:
                            var hasNext = i + 1 < valueSpan.Length;

                            if (i > 0 && hasNext)
                            {
                                var nextChar = valueSpan[i + 1];

                                if (!char.IsUpper(nextChar) && nextChar != separator)
                                {
                                    builder.Append(separator);
                                }
                            }

                            break;

                        case SeparatedCaseState.Lower:
                        case SeparatedCaseState.NewWord:
                            builder.Append(separator);
                            break;
                    }

                    builder.Append(char.ToLowerInvariant(valueSpan[i]));
                    state = SeparatedCaseState.Upper;
                }
                else if (valueSpan[i] == separator)
                {
                    builder.Append(separator);
                    state = SeparatedCaseState.Start;
                }
                else
                {
                    if (state == SeparatedCaseState.NewWord)
                    {
                        builder.Append(separator);
                    }

                    builder.Append(valueSpan[i]);
                    state = SeparatedCaseState.Lower;
                }
            }

            return builder.ToString();
        }
    }
}