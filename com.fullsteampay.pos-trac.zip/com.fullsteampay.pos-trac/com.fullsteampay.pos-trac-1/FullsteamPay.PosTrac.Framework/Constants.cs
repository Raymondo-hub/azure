﻿namespace FullsteamPay.PosTrac.Framework
{
    /// <summary>
    /// Represents a static holder class for constants used throughout the application.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The default length of the automatically generated portion of the activation code, before any prefixes or
        /// suffixes are added.
        /// </summary>
        public const int ActivationCodeDefaultCodeGenerateLength = 7;

        /// <summary>
        /// The default maximum number of activation codes to retain for each terminal.
        /// </summary>
        public const int ActivationCodeDefaultMaximumConcurrentCodes = 5;

        /// <summary>
        /// The string representing the maximum time span that can be configured for the broker activation code rotation interval.
        /// </summary>
        public const string BrokerCodeRotationInternvalMaximumTimeSpanFormat = "06:00:00";

        /// <summary>
        /// The string representing the minimum time span that can be configured for the broker activation code rotation interval.
        /// </summary>
        public const string BrokerCodeRotationInternvalMinimumTimeSpanFormat = "00:00:30";

        /// <summary>
        /// The minimum number of seconds with which the broker activation code rotation interval can be configured.
        /// </summary>
        public const int BrokerCodeRotationIntervalDefaultSeconds = 300;

        /// <summary>
        /// The name of the Azure Cosmos DB database.
        /// </summary>
        public const string CosmosDatabaseName = "PosTrac";

        /// <summary>
        /// The naming format for the discriminated identifier used in Cosmos entities.
        /// </summary>
        public const string CosmosEntityDiscriminatedIdFormat = "{0}|{1}";

        /// <summary>
        /// The name of the Azure Cosmos DB container for terminals.
        /// </summary>
        public const string CosmosTerminalContainerName = "Terminals";

        /// <summary>
        /// The naming format for the redis pub/sub channel where messages are sent to the broker service.
        /// </summary>
        public const string RedisBrokerSubscriberChannelNameFormat = "{0}-broker";

        /// <summary>
        /// The naming format for the redis pub/sub channel where messages are sent to the control service.
        /// </summary>
        public const string RedisControlSubscriberChannelNameFormat = "{0}-control";

        /// <summary>
        /// The value that maps a client identifier from the ASP.NET routing subsystem.
        /// </summary>
        public const string WebSocketClientIdRoute = "/{clientId}";

        /// <summary>
        /// The name of the key that identifies the client identifier in route values.
        /// </summary>
        public const string WebSocketClientIdRouteValueKey = "clientId";
    }
}