﻿namespace FullsteamPay.PosTrac.Framework
{
    using System;

    /// <summary>
    /// Defines extension methods for the <see cref="Guid" /> class.
    /// </summary>
    public static class GuidExtensions
    {
        /// <summary>
        /// Converts the given value to a string identifier structure with dashes removed and normalized to lowercase
        /// alpha characters.
        /// </summary>
        /// <param name="value">The GUID to convert.</param>
        /// <returns>A string identifier structure based on the original GUID.</returns>
        /// <remarks>
        /// The <see cref="Guid" /> class already normalizes alpha characters to lowercase when the GUID is
        /// created/parsed, so no additional calls should be necessary to normalize the string output.
        /// </remarks>
        public static string ToNormalizedIdentifier(this Guid value) => value.ToString().Replace("-", string.Empty, StringComparison.Ordinal);
    }
}