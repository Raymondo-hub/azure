﻿namespace FullsteamPay.PosTrac.Framework
{
    using System.Text.Json;

    /// <summary>
    /// Describes a naming policy used to string based name to a snake case format.
    /// </summary>
    /// <remarks>
    /// This naming policy is for converting property names to snake case during de/serialization and only exists
    /// because there is not an official one currently in .NET 5. Most of the implementation of it comes from a munge of
    /// Newtonsoft.Json and Microsoft's PR to the corefx source. Once an official snake case naming policy is available
    /// in System.Text.Json this policy should be removed.
    /// </remarks>
    public sealed class JsonSnakeCaseNamingPolicy : JsonNamingPolicy
    {
        /// <inheritdoc />
        public override string ConvertName(string name) => name.ToSnakeCase();
    }
}